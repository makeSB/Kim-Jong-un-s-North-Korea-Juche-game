
#include <windows.h>
#include <tchar.h>
#include <string>
#include <fstream>
#include <graphics.h>
#include <iostream>
#include <cstdio>
#include <graphics.h>
#include <conio.h>
#include <bits/stdc++.h>
#include <queue>
#include <unordered_map>
#include <algorithm>
#include<easyx.h>
#include <mmsystem.h>
#pragma comment(lib, "MSIMG32.LIB")
#pragma comment(lib, "winmm.lib")
#undef UNICODE
#undef _UNICODE
using namespace std;
struct player {
	double all_money=100;
	long long  all_pollution=0;
	double all_xl=1;
	long long all_people=0;
	long long food=0;
	long long worker=0;
};
struct music {
	IMAGE p;
	string path;
};
bool ifbuild=false;
struct building_template {
	IMAGE map_picture[10];
	IMAGE logo;
	int dh_return=1;
	int add_food;
	int add_money;
	int cost_money;
	int add_pollution;
	int cost_can_use_people;
	int add_people;
	double add_xl;
	int kind=0;
};
struct building_canuse {
	bool use=false;
	int kindof_building;
	int x=-1;
	int y=-1;
	int Degree=100;
};
struct production_building {
	bool use=false;
	int kindof_building;
	int x=-1;
	int y=-1;
	int outx;
	int outy;
	int Degree=100;
};
struct ship_template {
	IMAGE logo;
	IMAGE map_picture[10];
	int dh_return=1;
	int walk_long;
	int arm_long;
	bool swim;
	int cost_money=0;
};
struct ship_canuse {
	bool use=false;
	int kind;
	int x;
	int y;
	int dx;
	int dy;
	int Degree=50;
	std::vector<std::pair<int, int>> path; // �洢����·��
	int path_index = -1;         // ��ǰ·��������
};
int this_is_real_music=0;
bool ifship=false;//��ȷ���������Ƿ��� 
int number_mod_ship;
music music_list[10];
ship_canuse player_ship_pool[50];
ship_canuse AI_ship_pool[50];
production_building player_shipbuilding_pool[50];
production_building AI_shipbuilding_pool[50];
building_canuse player_building_pool[50];
building_canuse AI_building_pool[50];
player people_player;
player AI_player;
const int map_size = 20;//�����С
const int logo_size =30;//ͼ���С
const int windows_height = 20;//��ͼ��
const int windows_width = 25;//��ͼ��
int AI_Financial_Crisis_Index;//Ѱ·
int need=1;
bool ifmore=false;
bool war = false;
int now_shipbuilding=1;
long long game_time=0;//��Ϸʱ
int zhen=0;//֡
IMAGE map_dx_draw[10];//����ͼƬ
IMAGE sp_logo[10];//����ͼ��
int AIbuilding_number[100]= {0};
double enqing_money=1; 
int zhongcheng=0;
int number_outnorth=0;
bool ifmusic=true; 
int map_dx[windows_height+1][windows_width+1] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};
int number_mod_building = 2;//ģ������
int map_qk_x;//����x
int map_qk_y;//����y
int i_1=0;
int l=1;
int makebuilding[100];
ExMessage msg;//�����Ϣ
//music;
// A*Ѱ·�㷨����Ľṹ�ͺ���
const COLORREF WIN_GRAY = RGB(192, 192, 192);
const COLORREF WIN_LIGHT = RGB(255, 255, 255);
const COLORREF WIN_DARK = RGB(128, 128, 128);
const COLORREF WIN_DARKER = RGB(64, 64, 64);
const COLORREF WIN_BLUE = RGB(0, 0, 128);
const COLORREF WIN_HIGHLIGHT = RGB(0, 0, 255);
// ����3D����ť
void drawWin31Button(int x, int y, int width, int height, const char* text, bool pressed = false) {
    if (pressed) {
        // ����״̬�İ�ť
        setfillcolor(WIN_DARK);
        fillrectangle(x, y, x + width, y + height);
        
        setlinecolor(WIN_DARKER);
        line(x, y, x + width, y); // �ϱ���
        line(x, y, x, y + height); // �����
        
        setlinecolor(WIN_LIGHT);
        line(x, y + height, x + width, y + height); // �±���
        line(x + width, y, x + width, y + height); // �ұ���
    } else {
        // ����״̬�İ�ť
        setfillcolor(WIN_GRAY);
        fillrectangle(x, y, x + width, y + height);
        
        setlinecolor(WIN_LIGHT);
        line(x, y, x + width, y); // �ϱ���
        line(x, y, x, y + height); // �����
        
        setlinecolor(WIN_DARK);
        line(x, y + height, x + width, y + height); // �±���
        line(x + width, y, x + width, y + height); // �ұ���
    }
    
    // ���ư�ť����
    settextcolor(BLACK);
    setbkmode(TRANSPARENT);
    RECT r = {x + 5, y + 5, x + width - 5, y + height - 5};
    drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

// ���ƴ��ڱ�����
void drawWin31TitleBar(int x, int y, int width, const char* title) {
    // ����������
    setfillcolor(WIN_BLUE);
    fillrectangle(x, y, x + width, y + 20);
    
    // ��������
    settextcolor(WIN_LIGHT);
    setbkmode(TRANSPARENT);
    RECT r = {x + 5, y, x + width - 5, y + 20};
    drawtext(title, &r, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // ��������ť

}

// ���ƴ��ڱ߿�
void drawWin31WindowFrame(int x, int y, int width, int height) {
    // ��߿�
    setlinecolor(WIN_DARK);
    rectangle(x, y, x + width, y + height);
    
    // �ڱ߿�
    setlinecolor(WIN_LIGHT);
    rectangle(x + 1, y + 1, x + width - 1, y + height - 1);
    
    // �ڲ���Ӱ
    setlinecolor(WIN_DARK);
    line(x + 2, y + height - 2, x + width - 2, y + height - 2);
    line(x + width - 2, y + 2, x + width - 2, y + height - 2);
}

// ����Windows 3.1���Ĵ���
void drawWin31Window(int x, int y, int width, int height, const char* title) {
    // ���ƴ��ڱ���
    setfillcolor(WIN_GRAY);
    fillrectangle(x, y, x + width, y + height);
    
    // ���Ʊ�����
    drawWin31TitleBar(x, y, width, title);
    
    // ���ƴ��ڱ߿�
    drawWin31WindowFrame(x, y, width, height);
}

// ��ʼ��Windows 3.1���
void initWin31Style() {
    // ���ñ���ɫ
    setbkcolor(WIN_GRAY);
    cleardevice();
    
    // ����Windows 3.1��������
    LOGFONT lf;
    gettextstyle(&lf);
    lf.lfHeight = 12;
    lf.lfWeight = FW_NORMAL;
    strcpy(lf.lfFaceName, "System");
    settextstyle(&lf);
}
struct Node {
	int x, y;
	int g, h, f;
	Node* parent;

	Node(int x, int y) : x(x), y(y), g(0), h(0), f(0), parent(nullptr) {}

	bool operator==(const Node& other) const {
		return x == other.x && y == other.y;
	}
};

namespace std {
	template <>
	struct hash<Node> {
		size_t operator()(const Node& node) const {
			return hash<int>()(node.x) ^ (hash<int>()(node.y) << 1);
		}
	};
}
int number_music=0;
std::string this_is_real_music_a(int a){
	if (a>1){
		a=a%2;
	}
	if(a==0){
		return "music\\1.mp3";
	}
	else if(a==1){
		return "music\\1.mp3";
	}
}
std::string zhongcheng_said_c(int a){
	if(a<=50){
		zhongcheng+=1;
		return "Ϧ�����£������о�  "; 
		
	}
	else if(a>50&&a<150){
		zhongcheng+=2;
		return "̫�����������õ�δ��"; 
	}
	else if(a>=150){
		zhongcheng+=3;
		return "����̫����          "; 
	}
	else if(a==0){
		return "������壿           "; 
	}
	else{
		return "Ϊ�����Ǹ���         "; 
	} 
}
std::string zhongcheng_said_z(int a,int b){
	if(a>=b&&a<=2*b){
		zhongcheng+=1;
		return "���Ѵ��о�  "; 
	}
	else if(a>2*b&&a<=3*b){
		zhongcheng+=2;
		return "ȫ�����С��"; 
	}
	else if(a>3*b){
		zhongcheng+=3;
		return "��������    "; 
	}
	else{
		return "�������     "; 
	} 
}
std::vector<std::pair<int, int>> find_path(int startX, int startY, int endX, int endY) {
	// ���������б��͹ر��б�
	auto cmp = [](Node* a, Node* b) {
		return a->f > b->f;
	};
	std::priority_queue<Node*, std::vector<Node*>, decltype(cmp)> openList(cmp);
	std::unordered_map<Node, Node*> nodeMap;

	// �������ڵ�
	Node* startNode = new Node(startX, startY);
	startNode->h = abs(startX - endX) + abs(startY - endY);
	startNode->f = startNode->h;
	openList.push(startNode);
	nodeMap[*startNode] = startNode;

	// �������飨�ϡ��ҡ��¡���
	int dx[4] = {0, 1, 0, -1};
	int dy[4] = {1, 0, -1, 0};

	while (!openList.empty()) {
		Node* currentNode = openList.top();
		openList.pop();

		// ��������յ㣬����·��
		if (currentNode->x == endX && currentNode->y == endY) {
			std::vector<std::pair<int, int>> path;
			while (currentNode) {
				path.push_back(std::make_pair(currentNode->x, currentNode->y));
				currentNode = currentNode->parent;
			}
			std::reverse(path.begin(), path.end());

			// �����ڴ�
			for (auto& pair : nodeMap) {
				delete pair.second;
			}
			return path;
		}

		// ̽�����ڽڵ�
		for (int i = 0; i < 4; i++) {
			int nx = currentNode->x + dx[i];
			int ny = currentNode->y + dy[i];

			// ���߽�͵��Σ�������ˮ��
			if (nx < 0 || nx >= windows_width || ny < 0 || ny >= windows_height || map_dx[ny][nx] != 0) {
				continue;
			}

			Node neighbor(nx, ny);
			if (nodeMap.find(neighbor) == nodeMap.end()) {
				Node* newNode = new Node(nx, ny);
				newNode->parent = currentNode;
				newNode->g = currentNode->g + 1;
				newNode->h = abs(nx - endX) + abs(ny - endY);
				newNode->f = newNode->g + newNode->h;

				openList.push(newNode);
				nodeMap[neighbor] = newNode;
			}
		}
	}

	// �����ڴ�
	for (auto& pair : nodeMap) {
		delete pair.second;
	}

	return std::vector<std::pair<int, int>>(); // û���ҵ�·��
}

int fuck_Hyperspatial_Overlapping_Architecture() { //�������ѵ�
	bool b101=true;
	for(int i=0; i<50; i++) {
		if(player_building_pool[i].use ||player_shipbuilding_pool[i].use) {
			if((map_qk_x==player_building_pool[i].x&&map_qk_y==player_building_pool[i].y)||(map_qk_x==player_shipbuilding_pool[i].x&&map_qk_y==player_shipbuilding_pool[i].y)) {
				b101=false;
				break;
			}
		}
	}
	return b101;
}
int check_ifmake(int key) {
	int b101010=false;
	for(int i=1; i<=i_1; i++) {
		if(makebuilding[i]==key) {
			b101010=true;
			break;
		}
	}
	return b101010;
}
int check_shiphouse(int number_mod_building,production_building player_shipbuilding_pool[50],int map_qk_x,int map_qk_y) {
	bool b1010=false;
	for(int i=0; i<50; i++) {
		if(player_shipbuilding_pool[i].use==true) {
			if(player_shipbuilding_pool[i].x==map_qk_x&&player_shipbuilding_pool[i].y==map_qk_y) {
				b1010=true;
			}
		}
	}
	return b1010;
}
int PhantomRoweronaDustySea(int x,int y,int j) { //���μ��
	if(j==7) {
		bool ifok=false;
		int tryDirections[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
		for (int i = 0; i < 4; i++) {
			int newX = x + tryDirections[i][0];
			int newY = y + tryDirections[i][1];
			if (newX >= 0 && newX <= windows_height && newY >= 0 && newY <= windows_width && map_dx[newY][newX] == 0) {
				ifok=true;
			}
		}
		return ifok;
	} else {
		return true;
	}
}

int main() {
	//��־����
	SYSTEMTIME st;
	GetLocalTime(&st);
	std::stringstream ss;
	ss << "logs\\"
	   << std::setw(2) << std::setfill('0') << st.wMonth  // �·ݲ���
	   << std::setw(2) << std::setfill('0') << st.wDay      // ���ڲ���
	   << std::setw(2) << std::setfill('0') << st.wHour       // Сʱ����
	   << std::setw(2) << std::setfill('0') << st.wMinute       // ���Ӳ���
	   << ".txt";
	initgraph((windows_width+2) * map_size+logo_size+100, (windows_height+1) * map_size+logo_size+150,EX_SHOWCONSOLE);
	std::string narrowPath = ss.str();
	ofstream outFile(narrowPath.c_str());
	int witchship=1;
	bool welcome_back_commander=false;
	srand(time(0));
	number_mod_building=GetPrivateProfileInt("game","game_number",7,"mode\\fuck_number.ini");
	number_mod_ship=GetPrivateProfileInt("ship","ship_number",1,"mode\\fuck_number.ini");
	people_player.all_money=100;
	
	//��������
	loadimage(&map_dx_draw[1],_T("mode\\Topography\\lu.png"));
	loadimage(&map_dx_draw[0],_T("mode\\Topography\\hai.png"));
	loadimage(&sp_logo[0],_T("mode\\Topography\\empty.png"));
	loadimage(&sp_logo[2],_T("mode\\Topography\\empty_2.png"));
	loadimage(&sp_logo[1],_T("mode\\Topography\\logo_jz.png"));
	loadimage(&sp_logo[3],_T("mode\\Topography\\zhongchen.jpg"));
	loadimage(&sp_logo[4],_T("mode\\Topography\\key.png"));
	loadimage(&sp_logo[5],_T("mode\\Topography\\r.png"));
	loadimage(&sp_logo[6],_T("mode\\Topography\\l.png"));
	ifstream read;
	////read.open("mode\\fuck_nemeber.txt");
	//read>>number_mod_building;
	//read.close();
	//���벢��ʼ��������Ϣ
	building_template building[number_mod_building+1];//��1��Խ��
	ship_template ship[number_mod_ship+1];
	AI_player.all_money=150;
	war=true;
	//���뽨��
	for (int i = 0; i <=number_mod_building; i++) {
		//����ͼ��
		string path="mode\\build\\" + to_string(i) + "\\Animation\\logo.png";
		loadimage(&building[i].logo, path.c_str());
		//����ر�
		path = "mode\\build\\" + to_string(i) + "\\Animation\\Animation.ini";
		building[i].dh_return=GetPrivateProfileInt("zhen","nenember",1,path.c_str());
		for(int j=0; j<=building[i].dh_return; j++) {
			path = "mode\\build\\" + to_string(i) + "\\Animation\\m_p"+to_string(j)+".png";
			loadimage(&building[i].map_picture[j], path.c_str());
		}
		building[i].map_picture[0]=building[i].map_picture[1];
		path="mode\\build\\"+to_string(i)+"\\buildingconfig.ini";
		building[i].add_food=GetPrivateProfileInt("add","add_food",0,path.c_str());
		building[i].add_money=GetPrivateProfileInt("add","add_money",0, path.c_str());
		building[i].add_people=GetPrivateProfileInt("add","add_people",0,path.c_str());
		building[i].add_pollution=GetPrivateProfileInt("add","add_pollution",0,path.c_str());
		building[i].add_xl=GetPrivateProfileInt("add","add_xl",0,path.c_str());
		building[i].add_xl=1.0*building[i].add_xl/10;
		building[i].cost_money=GetPrivateProfileInt("cost","cost_money",0,path.c_str());
		building[i].cost_can_use_people=GetPrivateProfileInt("cost","cost_can_use_people",0,path.c_str());
		building[i].kind=GetPrivateProfileInt("kind","building_kind",0,path.c_str());
		if(building[i].kind==1) {
			makebuilding[i_1]=i;
			outFile<<i<<endl;
			i_1++;
		}

	}
	//��������
	for (int i = 1; i <=2; i++) {
		string path="music\\" + to_string(i) + "\\m.mp3";
		music_list[i].path=path;
		path="music\\" + to_string(i) + "\\p.PNG";
		loadimage(&music_list[i].p, path.c_str());
	} 
	//���뵥λ
	for (int i = 0; i <=number_mod_ship; i++) {
		//����ͼ��
		string path="mode\\ship\\" + to_string(i) + "\\Animation\\logo.png";
		loadimage(&ship[i].logo, path.c_str());
		//����ر�
		path = "mode\\ship\\" + to_string(i) + "\\Animation\\Animation.ini";
		ship[i].dh_return=GetPrivateProfileInt("zhen","number",1,path.c_str());
		for(int j=0; j<=ship[i].dh_return; j++) {
			path = "mode\\ship\\" + to_string(i) + "\\Animation\\m_p"+to_string(j)+".png";
			loadimage(&ship[i].map_picture[j], path.c_str());
		}
		ship[i].map_picture[0]=building[i].map_picture[1];
		path="mode\\ship\\"+to_string(i)+"\\shipconfig.ini";
		ship[i].arm_long=GetPrivateProfileInt("ship","arm_long",0,path.c_str());
		ship[i].walk_long=GetPrivateProfileInt("ship","walk_long",0,path.c_str());
		ship[i].swim=GetPrivateProfileInt("can_you_swim","YorN",0,path.c_str());
		ship[i].cost_money=GetPrivateProfileInt("cost","cost_money",0,path.c_str());
	}
	setlinecolor(RED);//��Ϊ��ɫ
	setlinestyle(PS_SOLID | PS_ENDCAP_SQUARE, 3);
	outFile<<"building"<<endl;
	for(int i=1; i<=number_mod_building; i++) {
		outFile<<"-------------"<<i<<"-------------"<<endl;
		outFile<<"����ʳ��"<<building[i].add_food<<endl;
		outFile<<"����Ǯ"<<building[i].add_money<<endl;
		outFile<<"������"<<building[i].add_people<<endl;
		outFile<<"����Ч��"<<building[i].add_xl<<endl;
		outFile<<"������Ⱦ"<<building[i].add_pollution<<endl;
		outFile<<"�����˿�"<<building[i].cost_can_use_people<<endl;
		outFile<<"����Ǯ"<<building[i].cost_money<<endl;
		outFile<<"����"<<building[i].kind<<endl<<endl;
	}
	outFile<<"ship"<<endl;
	for(int i=1; i<=number_mod_ship; i++) {
		outFile<<"-------------"<<i<<"-------------"<<endl;
		outFile<<"������Χ"<<ship[i].arm_long<<endl;
		outFile<<"����"<<ship[i].walk_long<<endl;
	}
	//��Ϸ������ 
	//��Ϸǰ�ض����
	
	putimage(0,windows_height*map_size+logo_size+20,&sp_logo[3]); 
	settextcolor(BLACK);
	setbkcolor(WHITE); 
	settextstyle(15, 0, "����");
	setbkcolor(WHITE); 
	people_player.all_money=10000000;
	cleardevice();
	mciSendString(TEXT("open music\\1\\m.mp3 alias 1"),NULL,0,NULL);
	mciSendString(TEXT("open music\\2\\m.mp3 alias 2"),NULL,0,NULL);
	mciSendString(TEXT("play 1"),NULL,0,NULL);
	
	while(1) {
		zhen++;
		zhen=zhen%10;
		if(zhen==1) {
		
			game_time++;
			game_time=game_time%1500;
			if(zhongcheng<6&&game_time%1500==0&&people_player.worker>10){
			    for(int i=0;i<50;i++){
			        if(player_ship_pool[i].use==false){
			            player_ship_pool[i].use=true;
				        player_ship_pool[i].kind=2;
				        for(int j=0;j<50;j++){
				            if(player_shipbuilding_pool[j].use==true){
			                    player_ship_pool[i].x=player_shipbuilding_pool[j].outx;
			                    player_ship_pool[i].y=player_shipbuilding_pool[j].outy;
			                    break;
			                }	
					    }
			            for(int j=0;j<50;j++){
		               		 if(AI_shipbuilding_pool[j].use==true){	
				                player_ship_pool[i].dx=AI_shipbuilding_pool[j].outx;
				                player_ship_pool[i].dy=AI_shipbuilding_pool[j].outy;
				                break;
			                }	
			            }
				            // ����·������ͳ�ʼ��
		            	player_ship_pool[i].path = find_path(player_ship_pool[i].x, player_ship_pool[i].y, player_ship_pool[i].dx, player_ship_pool[i].dy);
			       		if (!player_ship_pool[i].path.empty()) {
			            	player_ship_pool[i].path_index = 1; // �ӵ�һ��·���㿪ʼ
			        	} else {
		               		player_ship_pool[i].path_index = -1;
		            	}
			            break;
			        }
					
			    }
			}
			if(game_time%1500==0) {
				outFile<<"==============================================="<<endl;
				outFile<<"��ʼ���������Դͳ��"<<endl;

				int number_makefood=0;
				int number_makepeople=0;
				int number_makemoney=1;
				int number_pollution=0;
				double number_makexl=1;
				double maybemoney=0;
				int kind_makemoney=0;
				for(int i=0; i<50; i++) {
					if(player_building_pool[i].use==true) {
						maybemoney+=building[player_building_pool[i].kindof_building].add_money;
						number_makepeople+=building[player_building_pool[i].kindof_building].add_people;
						number_pollution+=building[player_building_pool[i].kindof_building].add_pollution;
						number_makexl+=1.0*building[player_building_pool[i].kindof_building].add_xl;
						number_makefood+=building[player_building_pool[i].kindof_building].add_food;

						if(building[player_building_pool[i].kindof_building].add_money>0) {
							number_makemoney++;
							kind_makemoney=i;
						}
					}


				}
				people_player.all_people=number_makepeople;
				people_player.all_pollution=number_pollution;
				people_player.food=number_makefood;
				people_player.all_pollution=number_pollution;
				people_player.all_xl= number_makexl;
				people_player.worker=min(people_player.food,people_player.all_people);
				if(people_player.worker>number_makemoney*building[kind_makemoney].cost_can_use_people) {
					people_player.all_money+=people_player.all_xl*maybemoney;
				} else {
					people_player.all_money+=1.0*(people_player.worker/number_makemoney*building[kind_makemoney].cost_can_use_people)*people_player.all_xl*enqing_money;
				}
				outFile<<"���"<<endl;
				outFile<<"==============================================="<<endl;
				outFile<<"��ʼ����AI��Դͳ��"<<endl;
				number_makefood=0;
				number_makepeople=0;
				number_makemoney=1;
				number_pollution=0;
				number_makexl=1;
				maybemoney=0;
				kind_makemoney=0;

				for(int i=0; i<10; i++) {
					AIbuilding_number[i]=0;
				}
				outFile<<"ͳ�ƻغ�������"<<endl;
				for(int i=0; i<50; i++) {
					if(AI_building_pool[i].use==true) {
						int kind= AI_building_pool[i].kindof_building; 
						outFile<<"�������"<<building[kind].add_money<<endl;
						maybemoney+=         building[kind].add_money;
						outFile<<"�ۼ�"<< maybemoney<<endl;
						number_makepeople +=building[kind].add_people;
						number_pollution  +=building[kind].add_pollution;
						number_makexl     +=building[kind].add_xl;
						number_makefood   +=building[kind].add_food;
						AIbuilding_number[AI_building_pool[i].kindof_building]++;
						if(building[ AI_building_pool[i].kindof_building].add_money>0) {
							number_makemoney++;
							kind_makemoney=2;
						}
					}
				}
				outFile<<"���"<<endl;
				outFile<<"��ֵ"<<endl;
				AI_player.all_people=number_makepeople;
				AI_player.all_pollution=number_pollution;
				AI_player.food=number_makefood;
				AI_player.all_pollution=number_pollution;
				AI_player.all_xl= number_makexl;
				AI_player.worker=min(AI_player.food,AI_player.all_people);
				outFile<<"���"<<endl;
				outFile<<"���ù���"<<AI_player.worker<<endl;
				if(AI_player.worker>=(number_makemoney*building[kind_makemoney].cost_can_use_people)) {
					outFile<<"���˳������"<<endl;
					outFile<<"����"<<maybemoney <<endl;
					outFile<<"Ч��"<< AI_player.all_xl<<endl;
					AI_player.all_money+=AI_player.all_xl*maybemoney;
				} else {
					outFile<<"���˲��������"<<endl;
					outFile<<"����"<< maybemoney<<endl;
					outFile<<"Ч��"<< AI_player.all_xl<<endl;
					AI_player.all_money+=1.0*min(1.0, (double)AI_player.worker / (number_makemoney * building[kind_makemoney].cost_can_use_people))*AI_player.all_xl*maybemoney;
				}
				outFile<<"���"<<endl;
				outFile<<AI_player.all_money<<endl;
				outFile<<"==============================================="<<endl;
			}
			if (game_time % 1500 == 0) {
				outFile<<"AI��ʼȷ�Ͻ���"<<endl;
				bool found = false;
				int x_j = 0;
				if(AI_player.all_money>=200){
					war=true;
				}
				else{
					war=false;
				}
				
				if (war == false) {
					if (AI_player.all_pollution >= 15) {
						x_j = 5;

					} else if (AIbuilding_number[2]% (3*(AIbuilding_number[4]+1)) == 0 && AIbuilding_number[2] != 0) {
						x_j = 4;
					} else if(AI_player.worker > AIbuilding_number[2] * building[2].cost_can_use_people) {
						x_j = 2;
					} else if (AI_player.worker < AIbuilding_number[2] * building[2].cost_can_use_people) {
						if (AI_player.all_people >= AI_player.food) {
							x_j = 3;
						} else {
							x_j = 6;
						}
					} else if (AI_player.food == 0) {
						x_j = 3;
					} else if (AI_player.all_people == 0) {
						x_j = 6;
					}

					else {
						x_j = 2;
					}
				} else {
					for(int i=0; i<50; i++) {
						if(AI_shipbuilding_pool[i].use==true) {
							found=true;
							for(int j=0; j<50; j++) {
								if(AI_ship_pool[j].use==false) {
									if(AI_player.all_money>=ship[1].cost_money) {
										AI_player.all_money-=ship[1].cost_money;
										AI_ship_pool[i].use=true;
										AI_ship_pool[i].x=AI_shipbuilding_pool[i].outx;
										AI_ship_pool[i].y=AI_shipbuilding_pool[i].outy;
										for(int j=0; j<50;j++){
											if(player_ship_pool[i].use==true){
												AI_ship_pool[i].dx=player_shipbuilding_pool[i].x;
												AI_ship_pool[i].dy=player_shipbuilding_pool[i].y;
												break;
											}
											else{
												AI_ship_pool[i].dx=AI_ship_pool[i].x;
												AI_ship_pool[i].dy=AI_ship_pool[i].y;
											}
										}
										
										AI_ship_pool[i].kind=1;
										break;
									} else {
										break;
									}
								}
							}
							break;
						} else {
							x_j=7;
						}
					}
				}
				outFile<<"AIȷ�����"<<endl;
				outFile<<"==============================================="<<endl;
				int rnx = 0;
				int rny = 0;
				int outx;
				int outy;
				int attempts = 0;
				int max_attempts = 100; // ��������ѭ��
				outFile<<"��ʼȷ�Ͻ���λ��"<<endl;
				// Ѱ�Һ��ʵ�λ��
				while (!found && attempts < max_attempts) {
					attempts++;
					rnx = rand() % (windows_width / 2);
					rny = rand() % (windows_height-2);
					if (rny >= 0 && rny < windows_height && rnx >= 0 && rnx < windows_width && map_dx[rny][rnx] == 1&&PhantomRoweronaDustySea(rnx,rny,x_j)) {
						bool overlap = false;
						for (int i = 0; i < 50; i++) {
							if (AI_building_pool[i].use && AI_building_pool[i].x == rnx && AI_building_pool[i].y == rny) {

								overlap = true;
								break;
							}
						}
						if (!overlap) {
							found = true;
						}
					}
				}
				outFile<<"AIȷ�����"<<endl;
				outFile<<"==============================================="<<endl;
				outFile<<"AI��ʼȷ���ڳ���λ�ú�Ǯ"<<endl;
				if (found&&AI_player.all_money>=building[x_j].cost_money&&x_j!=7) {
					for (int i = 0; i < 50; i++) {
						if (AI_building_pool[i].use==false) {
							AI_building_pool[i].use = true;
							AI_building_pool[i].x = rnx;
							AI_building_pool[i].y = rny;
							AI_building_pool[i].kindof_building = x_j;
							AI_player.all_money-=building[x_j].cost_money;
							outFile<<"������"<<x_j<<"��"<<rnx<<" "<<rny<<endl;
							outFile<<"ȷ���ڳ�"<<i<<endl;
							break;
						}

						else if(!AI_shipbuilding_pool[i].use&&x_j==7) {
							if(PhantomRoweronaDustySea(rnx,rny,x_j)) {
								int tryDirections[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
								for (int j = 0; j < 4; j++) {
									int newX = rnx + tryDirections[j][0];
									int newY = rny + tryDirections[j][1];
									if (newX >= 0 && newX <= windows_height && newY >= 0 && newY <= windows_width && map_dx[newY][newX] == 0) {
										outx=newX;
										outy=newY;
										break;
									}
								}
							}
							AI_shipbuilding_pool[i].use = true;
							AI_shipbuilding_pool[i].x = rnx;
							AI_shipbuilding_pool[i].y = rny;
							AI_shipbuilding_pool[i].outx= outx;
							AI_shipbuilding_pool[i].outy = outy;
							AI_shipbuilding_pool[i].kindof_building = x_j;
							AI_player.all_money-=building[x_j].cost_money;
							outFile<<"������"<<x_j<<"��"<<rnx<<" "<<rny<<endl;
							outFile<<"������"<<outx<<" "<<outy<<endl;
							outFile<<"ȷ���ڳ�"<<i<<endl;
							break;
						}

					}
				}
				outFile<<"==============================================="<<endl;
			}
			
			if(game_time%100==0) {
				// �ƶ���Ҵ�ֻ����·����
				for (int i = 0; i < 50; i++) {
					if (player_ship_pool[i].use && player_ship_pool[i].path_index >= 0) {
						// ����Ƿ���·����
						if (player_ship_pool[i].path_index < player_ship_pool[i].path.size()) {
							// �ƶ�����һ��·����
							player_ship_pool[i].x = player_ship_pool[i].path[player_ship_pool[i].path_index].first;
							player_ship_pool[i].y = player_ship_pool[i].path[player_ship_pool[i].path_index].second;
							player_ship_pool[i].path_index++;
						} else {
							// �����յ㣬���·��
							player_ship_pool[i].path.clear();
							player_ship_pool[i].path_index = -1;
							if(player_ship_pool[i].kind==2){
								player_ship_pool[i].use=false;
							}
						}
					}
				}

				// �ƶ�AI��ֻ����·����
				for (int i = 0; i < 50; i++) {
					if (AI_ship_pool[i].use && AI_ship_pool[i].path_index >= 0) {
						// ����Ƿ���·����
						if (AI_ship_pool[i].path_index < AI_ship_pool[i].path.size()) {
							// �ƶ�����һ��·����
							AI_ship_pool[i].x = AI_ship_pool[i].path[AI_ship_pool[i].path_index].first;
							AI_ship_pool[i].y = AI_ship_pool[i].path[AI_ship_pool[i].path_index].second;
							AI_ship_pool[i].path_index++;
						} else {
							// �����յ㣬���·��
							AI_ship_pool[i].path.clear();
							AI_ship_pool[i].path_index = -1;
						}
					}
				}
			}
			//ͼ�����
			BeginBatchDraw();
		
			drawWin31Window((windows_width) * map_size+25,0,logo_size+10, (windows_height+1) * map_size+25, " ");
			drawWin31Window(0,0, (windows_width) * map_size+25 , (windows_height+1) * map_size+25, "Utopia Map");
			drawWin31Window(0,(windows_height+1) * map_size+25+logo_size,(windows_width) * map_size+40+logo_size,120, "Newspaper");
			putimage(5,windows_height*map_size+logo_size+68,&sp_logo[3]); 
			
			for(int i=0; i<=windows_height; i++) { //�������
				for(int j=0; j<=windows_width; j++)
					putimage(j*map_size+5,i*map_size+20,&map_dx_draw[map_dx[i][j]]);
			}
			
			putimage(0,(windows_height+1)*map_size+25,&sp_logo[1]);
			for(int i=1; i<=number_mod_building; i++) { //��ť��� you
				putimage((windows_width+1) * map_size+10,(i-1)*logo_size+20,&building[i].logo);
			}
			for(int i=number_mod_building+1; i<=windows_height-5; i++) { //������� you
				putimage((windows_width+1) * map_size+10,(i-1)*logo_size+20,&sp_logo[2]);
			}
			drawWin31Button(400+(enqing_money-1)*100,(windows_height+1)*map_size+logo_size+80,10,20, "<--",false) ;
			
			for(int i=1; i<=windows_height+1; i++) { //��ť��� xia
				putimage(i * logo_size,(windows_height+1)*map_size+25,&sp_logo[0]);
			}
			if(ifship==true) {//������ 
				for(int i=1; i<=number_mod_ship; i++) {
					putimage(i * logo_size,(windows_height+1)*map_size+25,&ship[i].logo);
				}
			}
			
			zhongcheng=0;
			settextcolor(BLACK);
			outtextxy(190,windows_height*map_size+logo_size+125, zhongcheng_said_c(people_player.all_money).c_str());
			outtextxy(190,windows_height*map_size+logo_size+104, zhongcheng_said_z(people_player.food,people_player.worker).c_str());
			if(enqing_money>1.5){
				zhongcheng+=1;
			}
			for(int i=0; i<50; i++) {
				if(player_building_pool[i].use==true)
					putimage(player_building_pool[i].x*map_size+5,player_building_pool[i].y*map_size+20,&building[player_building_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);
				if(AI_building_pool[i].use==true)
					putimage(AI_building_pool[i].x*map_size+5,AI_building_pool[i].y*map_size+20,&building[AI_building_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);

				if(player_shipbuilding_pool[i].use==true)
					putimage(player_shipbuilding_pool[i].x*map_size+5,player_shipbuilding_pool[i].y*map_size+20,&building[player_shipbuilding_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);
				if(AI_shipbuilding_pool[i].use==true)
					putimage(AI_shipbuilding_pool[i].x*map_size+5,AI_shipbuilding_pool[i].y*map_size+20,&building[AI_shipbuilding_pool[i].kindof_building].map_picture[game_time%(building[AI_building_pool[i].kindof_building].dh_return+1)]);
			}
			for(int i=0; i<50; i++) {
				if(player_ship_pool[i].use==true) {
					putimage(player_ship_pool[i].x*map_size+5,player_ship_pool[i].y*map_size+20,&ship[player_ship_pool[i].kind].map_picture[1]);
				}
				if(AI_ship_pool[i].use==true) {
					putimage(AI_ship_pool[i].x*map_size+5,AI_ship_pool[i].y*map_size+20,&ship[AI_ship_pool[i].kind].map_picture[1]);
				}
			}
			
			if(map_qk_x<=windows_width&&map_qk_y<=windows_height) {
				rectangle(map_qk_x *map_size+5, map_qk_y * map_size+20, (map_qk_x + 1) * map_size+5, (map_qk_y + 1) * map_size+20);
			}
			drawWin31Window((windows_width+2) * map_size+logo_size,0,100,190, "Music");
			drawWin31Window((windows_width+2) * map_size+logo_size,190,100,  (windows_height+1) * map_size+logo_size-20 , "orther");
			drawWin31Button((windows_width+2) * map_size+logo_size+5,25,45,20, "<--",false) ;
			drawWin31Button((windows_width+2) * map_size+logo_size+50,25,45,20, "-->",false) ;
			drawWin31Button((windows_width+2) * map_size+logo_size+5,50,90,20, "||",false) ;
			drawWin31Window((windows_width+2) * map_size+logo_size+5,70,90,110, "PICTURE");
			putimage((windows_width+2) * map_size+logo_size+12,95,&music_list[((this_is_real_music)%2+1)].p);
			EndBatchDraw();//������ 
			//����ѡ�� ��λָ�� 
			if(!ifbuild&&!ifship) {
				map_qk_x=(msg.x-5)/map_size;
				map_qk_y=(msg.y-20)/map_size;
			}
			if (peekmessage(&msg, EX_MOUSE)) {
				switch (msg.message) {
					case WM_LBUTTONUP:
						ifmore=false;
						if(!welcome_back_commander) {//��ʼ���͵�λָ�� 
							for(int i=0; i<50; i++) {
								if(player_ship_pool[i].use) {
									if(player_ship_pool[i].x==map_qk_x&&player_ship_pool[i].y==map_qk_y) {
										welcome_back_commander=true;
										witchship=i;
										outFile<<"year sir"<<endl;
									}
								}
							}
						} else if(welcome_back_commander==true&&map_dx[map_qk_y][map_qk_x]==0&&map_qk_x<=windows_width&&map_qk_y<=windows_height) {
							outFile<<"I am here"<<player_ship_pool[witchship].x<<" "<<player_ship_pool[witchship].y<<endl;
							player_ship_pool[witchship].dy=map_qk_y;
							player_ship_pool[witchship].dx=map_qk_x;
							// ������·��
							player_ship_pool[witchship].path = find_path(player_ship_pool[witchship].x,player_ship_pool[witchship].y,map_qk_x,map_qk_y);

							if (!player_ship_pool[witchship].path.empty()) {
								player_ship_pool[witchship].path_index = 1; // �ӵ�һ��·���㿪ʼ��0�ǵ�ǰλ�ã�
							} else {
								player_ship_pool[witchship].path_index = -1;
							}

							outFile<<"I will go to"<<map_qk_x<<" "<<map_qk_y<<endl;
							welcome_back_commander=false;
						}
						//���½��Ҫ������ 
						 if(ifbuild==false&&map_qk_x<=windows_width&&map_dx[map_qk_y][map_qk_x]!=0&&fuck_Hyperspatial_Overlapping_Architecture()) {
							ifbuild=true;
						}
						else if(msg.y>(windows_height)*map_size+logo_size+80&&msg.y<(windows_height)*map_size+logo_size+185&&msg.x>400+(enqing_money-1)*10&&msg.x<400+(enqing_money-1)*100+20&&msg.x<500){
							if(!ifmore){
								ifmore=true;
								cout<<"win:";
							}
							
						}
						
						//ѡ���� 
						else if(msg.y>=(windows_height+1)*map_size&&ifship&&msg.y<=(windows_height+1)*map_size+logo_size+10) {
							int key_ship=msg.x/logo_size;
							if(people_player.all_money>=ship[key_ship].cost_money) {
								people_player.all_money-=ship[key_ship].cost_money;

								for(int i=0; i<50; i++) {
									if(player_ship_pool[i].use==false) {
										player_ship_pool[i].use=true;
										player_ship_pool[i].x=player_shipbuilding_pool[now_shipbuilding].outx;
										player_ship_pool[i].y=player_shipbuilding_pool[now_shipbuilding].outy;
										player_ship_pool[i].dx=player_shipbuilding_pool[now_shipbuilding].outx;
										player_ship_pool[i].dy=player_shipbuilding_pool[now_shipbuilding].outy;
										player_ship_pool[i].kind=key_ship;
										break;
									}
								}
							}
						} else if(msg.x>(windows_width+1)*map_size&&ifbuild==true) {//ѡ������ 
							int key=(msg.y-20)/logo_size;
							key++;
							outFile<<key<<endl;
							if(people_player.all_money>=building[key].cost_money&&map_dx[map_qk_y][map_qk_x]==1) {
								
								outFile<<building[key].cost_money<<endl;
								outFile<<check_ifmake(key);
								for(int i=0; i<50; i++) {
									if(key==7) {
										if(player_shipbuilding_pool[i].use==false) {//������׼ 
											bool b100=false;
											if(map_dx[map_qk_y+1][map_qk_x]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x;
												player_shipbuilding_pool[i].outy=map_qk_y+1;
												b100=true;
											}
											if(map_dx[map_qk_y-1][map_qk_x]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x;
												player_shipbuilding_pool[i].outy=map_qk_y-1;
												b100=true;
											}
											if(map_dx[map_qk_y][map_qk_x-1]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x-1;
												player_shipbuilding_pool[i].outy=map_qk_y;
												b100=true;
											}
											if(map_dx[map_qk_y][map_qk_x+1]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x+1;
												player_shipbuilding_pool[i].outy=map_qk_y;
												b100=true;
											}
											if(b100) {
												player_shipbuilding_pool[i].use=true;
												player_shipbuilding_pool[i].kindof_building=key;
												player_shipbuilding_pool[i].x=map_qk_x;
												player_shipbuilding_pool[i].y=map_qk_y;
												ifbuild=false;
												b100=false;
												break;
											}
										}
									} else if(!check_ifmake(key)) {
										outFile<<check_ifmake(key);
										if(player_building_pool[i].use==false) {
											people_player.all_money-=building[key].cost_money;
											player_building_pool[i].use=true;
											player_building_pool[i].kindof_building=key;
											player_building_pool[i].x=map_qk_x;
											player_building_pool[i].y=map_qk_y;
											ifbuild=false;
											break;
										}
									}

								}
							}
						} else if(!ifbuild&&map_dx[map_qk_y][map_qk_x]) {
							for(int i=0; i<50; i++) {
								if(player_shipbuilding_pool[i].use==true) {
									if(player_shipbuilding_pool[i].x==map_qk_x&&player_shipbuilding_pool[i].y==map_qk_y) {
										ifship=true;
										now_shipbuilding=i;
										break;
									}
								}
							}
						}
						else if(msg.x>(windows_width+2) * map_size+logo_size&&msg.y<=90){
							string name="close "+to_string((this_is_real_music)%2+1);
							cout<<(this_is_real_music)%2+1<<endl;
							cout<<name<<endl;
							mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							name="open music\\"+to_string((this_is_real_music)%2+1)+"\\m.mp3 alias "+to_string((this_is_real_music)%2+1);
							mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							if(msg.x<(windows_width+2) * map_size+logo_size+50&&msg.y<=45){
								this_is_real_music--;
							}
							else if(msg.x>=(windows_width+2) * map_size+logo_size+50&&msg.y<=45){
								this_is_real_music++;
							}
							else if(msg.y>45){
								if(ifmusic==false){
									ifmusic=true;
								}
								else{
									ifmusic=false;
								}
							}
							if(ifmusic){
								name="play "+to_string((this_is_real_music)%2+1);
								cout<<(this_is_real_music)%2+1<<endl;
								cout<<name<<endl;
								mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							}
						}
						break;
					case WM_RBUTTONUP:
						ifbuild=false;
						ifship=false;
						ifmore=false;
						break;
					case WM_LBUTTONDOWN:
						if(ifmore==true){
							enqing_money=1+1.0*(msg.x-400)/100;
							cout<<enqing_money<<endl;
							putimage(5,windows_height*map_size+logo_size+68,&sp_logo[3]); 
							outtextxy(190,windows_height*map_size+logo_size+125, zhongcheng_said_c(people_player.all_money).c_str());
							outtextxy(190,windows_height*map_size+logo_size+104, zhongcheng_said_z(people_player.food,people_player.worker).c_str());
							putimage(400+(enqing_money-1)*100,(windows_height+1)*map_size+logo_size+80,&sp_logo[4]);
						}
				}
			}
		}
	}
	outFile.close();
	return 0;
}

