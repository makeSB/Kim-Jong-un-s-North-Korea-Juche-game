#include <windows.h>
#include <tchar.h>
#include <string>
#include <fstream>
#include <graphics.h>
#include <iostream>
#include <cstdio>
#include <graphics.h>
#include <conio.h>
#include <bits/stdc++.h>
#include <queue>
#include <unordered_map>
#include <algorithm>
#include<easyx.h>
#include <mmsystem.h>
#pragma comment(lib, "MSIMG32.LIB")
#pragma comment(lib, "winmm.lib")
#undef UNICODE
#undef _UNICODE
using namespace std;
struct player {
	double all_money=100;
	long long  all_pollution=0;
	double all_xl=1;
	long long all_people=0;
	long long food=0;
	long long worker=0;
};
struct music {
	IMAGE p;
	string path;
};
bool ifbuild=false;
struct building_template {
	IMAGE map_picture[10];
	IMAGE logo;
	int dh_return=1;
	int add_food;
	int add_money;
	int cost_money;
	int add_pollution;
	int cost_can_use_people;
	int add_people;
	double add_xl;
	int kind=0;
};
struct building_canuse {
	bool use=false;
	int kindof_building;
	int x=-1;
	int y=-1;
	int Degree=100;
};
struct production_building {
	bool use=false;
	int kindof_building;
	int x=-1;
	int y=-1;
	int outx;
	int outy;
	int Degree=100;
};
struct ship_template {
	IMAGE logo;
	IMAGE map_picture[10];
	int dh_return=1;
	int walk_long;
	int arm_long;
	bool swim;
	int cost_money=0;
	
};
struct ship_canuse {
	bool use=false;
	int kind;
	int x;
	int y;
	int dx;
	int dy;
	int Degree=50;
	std::vector<std::pair<int, int>> path; // �洢����·��
	int path_index = -1;         // ��ǰ·��������
	bool war=false;
	int war_object;
};
struct shoot{
	bool use=false;
	int x1;
	int x2;
	int y1;
	int y2;
	int duration=10;
};
struct AIStrategy {
    int phase; // 0=��չ, 1=����, 2=����
    int targetPriority[10]; // Ŀ�����ȼ��б�
    int forceBalance; // ����ƽ������
};

AIStrategy aiStrategy;

// ��ʼ��AI����
void initAIStrategy() {
    aiStrategy.phase = 0;
    // ����Ŀ�����ȼ������� > ���ý��� > ���½��� > ����
    aiStrategy.targetPriority[0] = 7; // ����
    aiStrategy.targetPriority[1] = 2; // ���ý���
    aiStrategy.targetPriority[2] = 1; // ���½���
    aiStrategy.forceBalance = 0;
}


// �Ż����Ŀ��ѡ����


int this_is_real_music=0;
bool ifship=false;//��ȷ���������Ƿ��� 
int number_mod_ship;
shoot light[20];
music music_list[10];
ship_canuse player_ship_pool[50];
ship_canuse AI_ship_pool[50];
production_building player_shipbuilding_pool[50];
production_building AI_shipbuilding_pool[50];
building_canuse player_building_pool[50];
building_canuse AI_building_pool[50];
player people_player;
player AI_player;
const int map_size = 20;//�����С
const int logo_size =30;//ͼ���С
const int windows_height = 20;//��ͼ��
const int windows_width = 25;//��ͼ��
int AI_Financial_Crisis_Index;//Ѱ·
int need=1;
bool ifmore=false;
bool war = false;
int now_shipbuilding=1;
long long game_time=0;//��Ϸʱ
int zhen=0;//֡
IMAGE map_dx_draw[10];//����ͼƬ
IMAGE sp_logo[100];//����ͼ��
int AIbuilding_number[100]= {0};
double enqing_money=1; 
int zhongcheng=0;
int number_outnorth=0;
int south_people=0;
bool ifmusic=true; 
int chooseAITarget(int x, int y) {
    int bestTarget = -1;
    float bestScore = -1.0f;
    
    for (int i = 0; i < 50; i++) {
        if (player_building_pool[i].use) {
            // �������
            float distance = sqrt(pow(x - player_building_pool[i].x, 2) + 
                                 pow(y - player_building_pool[i].y, 2));
            
            // �������ȼ��÷�
            float priority = 0.0f;
            for (int p = 0; p < 10; p++) {
                if (player_building_pool[i].kindof_building == aiStrategy.targetPriority[p]) {
                    priority = 10 - p; // ���ȼ�Խ�ߵ÷�Խ��
                    break;
                }
            }
            
            // �����ۺϵ÷֣����ȼ�/���룩
            float score = priority / (distance + 1.0f);
            
            if (score > bestScore) {
                bestScore = score;
                bestTarget = i;
            }
        }
    }
    
    return bestTarget;
}
int map_dx[windows_height+1][windows_width+1] = {
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0},
	{0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0},
	{0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
};
int map_weather[13][13];
int wind_think=0;
int windows_weatherlike=1;
int number_mod_building = 2;//ģ������
int map_qk_x;//����x
int map_qk_y;//����y
int i_1=0;
int l=1;
int makebuilding[100];
ExMessage msg;//�����Ϣ
int UI_number_makemoney;
void evaluateForceBalance() {
    int playerShips = 0;
    int aiShips = 0;
    
    for (int i = 0; i < 50; i++) {
        if (player_ship_pool[i].use) playerShips++;
        if (AI_ship_pool[i].use) aiShips++;
    }
    
    aiStrategy.forceBalance = aiShips - playerShips;
    
    // ���ݾ���ƽ��������Խ׶�
    if (aiStrategy.forceBalance > 2) {
        aiStrategy.phase = 2; // �����׶�
    } else if (aiStrategy.forceBalance > 0) {
        aiStrategy.phase = 1; // ���Ž׶�
    } else {
        aiStrategy.phase = 0; // ��չ�׶�
    }
}

// Эͬ��������

//music;
// A*Ѱ·�㷨����Ľṹ�ͺ���
const COLORREF WIN_GRAY = RGB(192, 192, 192);
const COLORREF WIN_LIGHT = RGB(255, 255, 255);
const COLORREF WIN_DARK = RGB(128, 128, 128);
const COLORREF WIN_DARKER = RGB(64, 64, 64);
const COLORREF WIN_BLUE = RGB(0, 0, 128);
const COLORREF WIN_HIGHLIGHT = RGB(0, 0, 255);
// ����3D����ť
void drawWin31Button(int x, int y, int width, int height, const char* text, bool pressed = false) {
    if (pressed) {
        // ����״̬�İ�ť
        setfillcolor(WIN_DARK);
        fillrectangle(x, y, x + width, y + height);
        
        setlinecolor(WIN_DARKER);
        line(x, y, x + width, y); // �ϱ���
        line(x, y, x, y + height); // �����
        
        setlinecolor(WIN_LIGHT);
        line(x, y + height, x + width, y + height); // �±���
        line(x + width, y, x + width, y + height); // �ұ���
    } else {
        // ����״̬�İ�ť
        setfillcolor(WIN_GRAY);
        fillrectangle(x, y, x + width, y + height);
        
        setlinecolor(WIN_LIGHT);
        line(x, y, x + width, y); // �ϱ���
        line(x, y, x, y + height); // �����
        
        setlinecolor(WIN_DARK);
        line(x, y + height, x + width, y + height); // �±���
        line(x + width, y, x + width, y + height); // �ұ���
    }
    
    // ���ư�ť����
    settextcolor(BLACK);
    setbkmode(TRANSPARENT);
    RECT r = {x + 5, y + 5, x + width - 5, y + height - 5};
    drawtext(text, &r, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
}

// ���ƴ��ڱ�����
void drawWin31TitleBar(int x, int y, int width, const char* title) {
    // ����������
    setfillcolor(WIN_BLUE);
    fillrectangle(x, y, x + width, y + 20);
    
    // ��������
    settextcolor(WIN_LIGHT);
    setbkmode(TRANSPARENT);
    RECT r = {x + 5, y, x + width - 5, y + 20};
    drawtext(title, &r, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
    
    // ��������ť

}

// ���ƴ��ڱ߿�
void drawWin31WindowFrame(int x, int y, int width, int height) {
    // ��߿�
    setlinecolor(WIN_DARK);
    rectangle(x, y, x + width, y + height);
    
    // �ڱ߿�
    setlinecolor(WIN_LIGHT);
    rectangle(x + 1, y + 1, x + width - 1, y + height - 1);
    
    // �ڲ���Ӱ
    setlinecolor(WIN_DARK);
    line(x + 2, y + height - 2, x + width - 2, y + height - 2);
    line(x + width - 2, y + 2, x + width - 2, y + height - 2);
}

// ����Windows 3.1���Ĵ���
void drawWin31Window(int x, int y, int width, int height, const char* title) {
    // ���ƴ��ڱ���
    setfillcolor(WIN_GRAY);
    fillrectangle(x, y, x + width, y + height);
    
    // ���Ʊ�����
    drawWin31TitleBar(x, y, width, title);
    
    // ���ƴ��ڱ߿�
    drawWin31WindowFrame(x, y, width, height);
}

// ��ʼ��Windows 3.1���
void initWin31Style() {
    // ���ñ���ɫ
    setbkcolor(WIN_GRAY);
    cleardevice();
    
    // ����Windows 3.1��������
    LOGFONT lf;
    gettextstyle(&lf);
    lf.lfHeight = 12;
    lf.lfWeight = FW_NORMAL;
    strcpy(lf.lfFaceName, "System");
    settextstyle(&lf);
}
struct Node {
	int x, y;
	int g, h, f;
	Node* parent;

	Node(int x, int y) : x(x), y(y), g(0), h(0), f(0), parent(nullptr) {}

	bool operator==(const Node& other) const {
		return x == other.x && y == other.y;
	}
};

namespace std {
	template <>
	struct hash<Node> {
		size_t operator()(const Node& node) const {
			return hash<int>()(node.x) ^ (hash<int>()(node.y) << 1);
		}
	};
}
int number_music=0;
std::string this_is_real_music_a(int a){
	if (a>1){
		a=a%2;
	}
	if(a==0){
		return "music\\1.mp3";
	}
	else if(a==1){
		return "music\\1.mp3";
	}
}
std::string zhongcheng_said_c(int a){
	if(a<=50){
		zhongcheng+=1;
		return "Ϧ�����£������о�  "; 
		
	}
	else if(a>50&&a<150){
		zhongcheng+=2;
		return "̫�����������õ�δ��"; 
	}
	else if(a>=150){
		zhongcheng+=3;
		return "����̫����          "; 
	}
	else if(a==0){
		return "������壿           "; 
	}
	else{
		return "Ϊ�����Ǹ���         "; 
	} 
}
std::string zhongcheng_said_z(int a,int b){
	if(a>=b&&a<=2*b){
		zhongcheng+=1;
		return "���Ѵ��о�  "; 
	}
	else if(a>2*b&&a<=3*b){
		zhongcheng+=2;
		return "ȫ�����С��"; 
	}
	else if(a>3*b){
		zhongcheng+=3;
		return "��������    "; 
	}
	else{
		return "�������     "; 
	} 
}
std::vector<std::pair<int, int>> find_path(int startX, int startY, int endX, int endY) {
    // ʹ�ö�������ȶ��������׼���ȶ���
    auto cmp = [](const Node* a, const Node* b) { return a->f > b->f; };
    std::priority_queue<Node*, std::vector<Node*>, decltype(cmp)> openList(cmp);
    
    // ʹ�ø���Ч�����ݽṹ�洢�ڵ�
    std::unordered_map<int, Node*> nodeMap;
    auto getKey = [](int x, int y) { return x * 1000 + y; };
    
    // �������ڵ�
    Node* startNode = new Node(startX, startY);
    startNode->h = abs(startX - endX) + abs(startY - endY);
    startNode->f = startNode->h;
    openList.push(startNode);
    nodeMap[getKey(startX, startY)] = startNode;
    
    // �������飨�ϡ��ҡ��¡���
    int dx[4] = {0, 1, 0, -1};
    int dy[4] = {1, 0, -1, 0};
    
    while (!openList.empty()) {
        Node* currentNode = openList.top();
        openList.pop();
        
        // ��������յ㣬����·��
        if (currentNode->x == endX && currentNode->y == endY) {
            std::vector<std::pair<int, int>> path;
            while (currentNode) {
                path.push_back(std::make_pair(currentNode->x, currentNode->y));
                currentNode = currentNode->parent;
            }
            std::reverse(path.begin(), path.end());
            
            // �����ڴ�
            for (auto& pair : nodeMap) {
                delete pair.second;
            }
            return path;
        }
        
        // ̽�����ڽڵ�
        for (int i = 0; i < 4; i++) {
            int nx = currentNode->x + dx[i];
            int ny = currentNode->y + dy[i];
            
            // ���߽�͵��Σ�������ˮ��
            if (nx < 0 || nx >= windows_width || ny < 0 || ny >= windows_height || map_dx[ny][nx] != 0) {
                continue;
            }
            
            int key = getKey(nx, ny);
            if (nodeMap.find(key) == nodeMap.end()) {
                Node* newNode = new Node(nx, ny);
                newNode->parent = currentNode;
                newNode->g = currentNode->g + 1;
                newNode->h = abs(nx - endX) + abs(ny - endY);
                newNode->f = newNode->g + newNode->h;
                
                openList.push(newNode);
                nodeMap[key] = newNode;
            }
        }
    }
    
    // �����ڴ�
    for (auto& pair : nodeMap) {
        delete pair.second;
    }
    
    return std::vector<std::pair<int, int>>(); // û���ҵ�·��
}

int fuck_Hyperspatial_Overlapping_Architecture() { //�������ѵ�
	bool b101=true;
	for(int i=0; i<50; i++) {
		if(player_building_pool[i].use ||player_shipbuilding_pool[i].use) {
			if((map_qk_x==player_building_pool[i].x&&map_qk_y==player_building_pool[i].y)||(map_qk_x==player_shipbuilding_pool[i].x&&map_qk_y==player_shipbuilding_pool[i].y)) {
				b101=false;
				break;
			}
		}
	}
	return b101;
}
int check_ifmake(int key) {
	int b101010=false;
	for(int i=1; i<=i_1; i++) {
		if(makebuilding[i]==key) {
			b101010=true;
			break;
		}
	}
	return b101010;
}
int check_shiphouse(int number_mod_building,production_building player_shipbuilding_pool[50],int map_qk_x,int map_qk_y) {
	bool b1010=false;
	for(int i=0; i<50; i++) {
		if(player_shipbuilding_pool[i].use==true) {
			if(player_shipbuilding_pool[i].x==map_qk_x&&player_shipbuilding_pool[i].y==map_qk_y) {
				b1010=true;
			}
		}
	}
	return b1010;
}
int PhantomRoweronaDustySea(int x,int y,int j) { //���μ��
	if(j==7) {
		bool ifok=false;
		int tryDirections[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
		for (int i = 0; i < 4; i++) {
			int newX = x + tryDirections[i][0];
			int newY = y + tryDirections[i][1];
			if (newX >= 0 && newX <= windows_height && newY >= 0 && newY <= windows_width && map_dx[newY][newX] == 0) {
				ifok=true;
			}
		}
		return ifok;
	} else {
		return true;
	}
}
void coordinateAttack(int attackerIndex) {
    // Ѱ�Ҹ����Ѿ���λЭͬ����
    for (int i = 0; i < 50; i++) {
        if (i != attackerIndex && AI_ship_pool[i].use && !AI_ship_pool[i].war) {
            float distance = sqrt(pow(AI_ship_pool[attackerIndex].x - AI_ship_pool[i].x, 2) + 
                                 pow(AI_ship_pool[attackerIndex].y - AI_ship_pool[i].y, 2));
            
            // �������Ͻ���û�����񣬷�����ͬĿ��
            if (distance < 5.0f) {
                AI_ship_pool[i].war_object = AI_ship_pool[attackerIndex].war_object;
                AI_ship_pool[i].war = true;
                
                // ����·��
                AI_ship_pool[i].path = find_path(
                    AI_ship_pool[i].x, 
                    AI_ship_pool[i].y,
                    AI_building_pool[AI_ship_pool[i].war_object].x,
                    AI_building_pool[AI_ship_pool[i].war_object].y
                );
                AI_ship_pool[i].path_index = 1;
            }
        }
    }
}
    // �����׶��߼����ֲ���...

double how_long(double x1,double x2,double y1,double y2){
	 	int ssx=max(x1,x2)-min(x1,x2);
		int ssy=max(y1,y2)-min(y1,y2);
		int t=ssx*ssx+ssy*ssy;
		return sqrt(t);
}
void music_player(int x,int y){
	drawWin31Window(x,y,100,190, "Music");
	drawWin31Button(x+5,y+25,45,20, "<--",false) ;
	drawWin31Button(x+50,y+25,45,20, "-->",false) ;
	drawWin31Button(x+5,y+50,90,20, "||",false) ;
	drawWin31Window(x+5,y+70,90,110, "PICTURE");
	putimage((windows_width+2) * map_size+logo_size+12,95,&music_list[((this_is_real_music)%2+1)].p);
}
void newspaper(int x,int y){
	drawWin31Window(x+0,y,(windows_width) * map_size+35+logo_size,120, "Newspaper");
	putimage(x+5,windows_height*map_size+logo_size+68+y-((windows_height+1) * map_size+logo_size+25),&sp_logo[3]); 
	settextcolor(BLACK);
	outtextxy(x+190,windows_height*map_size+logo_size+125+y-((windows_height+1) * map_size+logo_size+25), zhongcheng_said_c(people_player.all_money).c_str());
	outtextxy(x+190,windows_height*map_size+logo_size+104+y-((windows_height+1) * map_size+logo_size+25), zhongcheng_said_z(people_player.food,people_player.worker).c_str());
	drawWin31Button(x+400+(enqing_money-1)*100,(windows_height+1)*map_size+logo_size+80+y-((windows_height+1) * map_size+logo_size+25),10,20, "<--",false) ;
}
void main_out(int number_mod_building,building_template building[8],ship_template ship[3]){
	drawWin31Window(0,0, (windows_width) * map_size+25 , (windows_height+1) * map_size+25, "Utopia Map");
	
	for(int i=0; i<=windows_height; i++) { //�������
		for(int j=0; j<=windows_width; j++)
			putimage(j*map_size+5,i*map_size+20,&map_dx_draw[map_dx[i][j]]);
	}
	for(int i=0; i<50; i++) {
		setlinecolor(RED);
		if(player_building_pool[i].use==true&&player_building_pool[i].Degree>=0){
			putimage(player_building_pool[i].x*map_size+5,player_building_pool[i].y*map_size+20,&building[player_building_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);
			if(player_building_pool[i].Degree!=100){
				line(player_building_pool[i].x*map_size+5,player_building_pool[i].y*map_size+20,player_building_pool[i].x*map_size+5+int(1.0*player_building_pool[i].Degree/100*20),player_building_pool[i].y*map_size+20);
			}
		}
		if(AI_building_pool[i].use==true&&AI_building_pool[i].Degree>=0){
			putimage(AI_building_pool[i].x*map_size+5,AI_building_pool[i].y*map_size+20,&building[AI_building_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);
			if(AI_building_pool[i].Degree!=100){
				line(AI_building_pool[i].x*map_size+5,AI_building_pool[i].y*map_size+20,AI_building_pool[i].x*map_size+5+int(1.0*AI_building_pool[i].Degree/100*20),AI_building_pool[i].y*map_size+20);
			}
		}
		if(player_shipbuilding_pool[i].use==true&&player_shipbuilding_pool[i].Degree>=100){
			
			putimage(player_shipbuilding_pool[i].x*map_size+5,player_shipbuilding_pool[i].y*map_size+20,&building[player_shipbuilding_pool[i].kindof_building].map_picture[game_time%(building[player_building_pool[i].kindof_building].dh_return+1)]);
		}
		if(AI_shipbuilding_pool[i].use==true)
			putimage(AI_shipbuilding_pool[i].x*map_size+5,AI_shipbuilding_pool[i].y*map_size+20,&building[AI_shipbuilding_pool[i].kindof_building].map_picture[game_time%(building[AI_building_pool[i].kindof_building].dh_return+1)]);
	}
	for(int i=0; i<50; i++) {
		setlinecolor(RED);
		if(player_ship_pool[i].use==true) {
			putimage(player_ship_pool[i].x*map_size+5,player_ship_pool[i].y*map_size+20,&ship[player_ship_pool[i].kind].map_picture[1]);
			if(player_ship_pool[i].Degree!=100)
				line(player_ship_pool[i].x*map_size+5,player_ship_pool[i].y*map_size+20,player_ship_pool[i].x*map_size+5+int(1.0*player_ship_pool[i].Degree/100*20),player_ship_pool[i].y*map_size+20);
		}
		if(AI_ship_pool[i].use==true) {
			putimage(AI_ship_pool[i].x*map_size+5,AI_ship_pool[i].y*map_size+20,&ship[AI_ship_pool[i].kind].map_picture[1]);
			if(player_ship_pool[i].Degree!=100)
				line(AI_ship_pool[i].x*map_size+5,AI_ship_pool[i].y*map_size+20,AI_ship_pool[i].x*map_size+5+int(1.0*AI_ship_pool[i].Degree/100*20),AI_ship_pool[i].y*map_size+20);
		}
	}
	
}
void build_building(int x,int y,building_template building[8]){
	drawWin31Window(x-5,0,logo_size+10, (windows_height+1) * map_size+25, " ");
	for(int i=1; i<=number_mod_building; i++) { //��ť��� you
		putimage(x,(i-1)*logo_size+20+y,&building[i].logo);
	}
	for(int i=number_mod_building+1; i<=windows_height-5; i++) { //������� you
		putimage(x,(i-1)*logo_size+20+y,&sp_logo[2]);
	}
}
void ship_out(int x,int y,ship_template ship[3]){
	for(int i=1; i<=windows_height+1; i++) { //��ť��� xia
		putimage(i * logo_size+x,y,&sp_logo[0]);
	}
	if(ifship==true) {//������ 
		for(int i=1; i<=number_mod_ship; i++) {
			putimage(i * logo_size+x,y,&ship[i].logo);
		}
	}
}
string pingJ(int a){
	if(a<=10){
		return "��";
	}
	else if(a>10&&a<20){
		return "һ��";
	} 
	else{
		return "��"; 
	} 
} 
void said_out(int x,int y){
	drawWin31Window(x,y,(windows_height-5)* map_size,275, "�⽻");
	drawWin31Window(x+5,y+25,(windows_height-5)* map_size-10,100, "China");
	drawWin31Button(x+10,y+50,(windows_height-5)* map_size-20,20,"���ú�ƽ ����ս��"); 
	drawWin31Button(x+10,y+75,(windows_height-5)* map_size-20,20,"����Ԯ��"); 
	drawWin31Window(x+5,y+130,(windows_height-5)* map_size-10,100, "Russia");
	drawWin31Button(x+10,y+160,(windows_height-5)* map_size-20,20,"ս��Ԯ��");
	drawWin31Button(x+10,y+235,(windows_height-5)* map_size-20,30,pingJ(wind_think).c_str());
}
void weatcher(int x,int y){
	drawWin31Window(x,y,(windows_height-5)* map_size,(windows_width-9)* map_size, "weather");
	for(int i=3;i<windows_height-3;i++){
		for(int j=11;j<windows_width;j++){
			putimage((j-11)*map_size+x+9,(i-3)*map_size+y+25,&map_dx_draw[map_dx[i][j]]);
		}
	}
	for(int i=0;i<13;i++){
		for(int j=0;j<13;j++){
			if(map_weather[i][j]==2){
				putimage(j*map_size+x+9,i*map_size+y+25,&map_dx_draw[2]);
			}
		}
	}
	said_out(x,y+(windows_width-9)* map_size);
}
void drawLightEffects() {
    for (int i = 0; i < 20; i++) {
        if (light[i].use) {
            // ���������յ㣨��Ļ���꣩
            int startX =light[i].x1 * map_size + 5 + map_size/2;
            int startY = light[i].y1 * map_size + 20 + map_size/2;
            int endX = light[i].x2 * map_size + 5 + map_size/2;
            int endY = light[i].y2 * map_size + 20 + map_size/2;
            
            // ����������
            setlinecolor(YELLOW);
            setlinestyle(PS_SOLID, 3);
            line(startX, startY, endX, endY);
        }
    }
}
void shoot_head(int centerX,int centerY){
	COLORREF crosshairColor = WHITE;
    int size = 30;
    // ����׼��
    setcolor(crosshairColor);
 // ����������ʽΪʵ�ߣ�����Ϊ2����
    
    // ����ˮƽ��
    line(centerX - size/2, centerY, centerX + size/2, centerY);
    
    // ���ƴ�ֱ��
    line(centerX, centerY - size/2, centerX, centerY + size/2);
    
    // ��ѡ�������ⲿԲȦ
    circle(centerX, centerY, size/2);
}
void longlong(int sx,int sy){
	drawWin31Window(sx,sy,100,  (windows_height+1) * map_size+logo_size-45 , "worker");
	drawWin31Button(sx+10,sy+25,20,((windows_height+1) * map_size+logo_size-20)*1.0*south_people/people_player.worker,"");
	drawWin31Button(sx+35,sy+25,20,((windows_height+1) * map_size+logo_size-20)*1.0*people_player.worker/people_player.food,"");
	drawWin31Button(sx+60,sy+25,20,((windows_height+1) * map_size+logo_size-20)*1.0*people_player.worker/people_player.all_people,"");	
}

void start_UI(){
	loadimage(&sp_logo[7],_T("mode\\Topography\\strat.png"));
	loadimage(&sp_logo[8],_T("mode\\Topography\\strat2.png"));
	loadimage(&sp_logo[9],_T("mode\\Topography\\strat3.png"));
	loadimage(&sp_logo[10],_T("mode\\Topography\\me.png"));
	mciSendString(TEXT("open music\\strat\\win95.wav alias 1000"),NULL,0,NULL);
	mciSendString(TEXT("open music\\strat\\t.wav alias 1001"),NULL,0,NULL);
	mciSendString(TEXT("play 1000"),NULL,0,NULL);
	putimage(0,0,&sp_logo[7]);
	Sleep(5000);
	setbkcolor(WHITE);
	cleardevice();
	putimage(0,0,&sp_logo[9]);
	drawWin31Window(600,100,300,300,"ѡ��");
	drawWin31Button(605,125,290,50,"��ʼ") ; 
	drawWin31Button(605,185,290,50,"����") ; 
	bool strat=false;
	while(!strat){
		//90
		bool me=true;
		if(peekmessage(&msg, EX_MOUSE)){
			switch(msg.message){
				case WM_LBUTTONUP:
					
					if(msg.x>=600&&msg.x<=900){
						if(msg.y>=125&&msg.y<=175){
							strat=true;
						}
						else if(msg.y>=185&&msg.y<=235){
							
							drawWin31Window(100,200,300,210,"������Ϣ") ; 
							drawWin31Button(105,225,290,25,"����: ��˥��") ; 
							drawWin31Button(105,255,290,25,"BILBIL: BreadMaker������") ; 
							drawWin31Button(105,285,290,25,"��������: C++ DevC++ Easyx") ; 
							drawWin31Button(105,315,195,25,"GitHub: makeSB") ; 
							putimage(305,315,&sp_logo[10]);
							
						}
						
					}
					else if(msg.x>=100&&msg.x<=400&&msg.y>=200&&msg.y<=410) {
						putimage(0,0,&sp_logo[9]);
						drawWin31Window(600,100,300,300,"ѡ��");
						drawWin31Button(605,125,290,50,"��ʼ") ; 
						drawWin31Button(605,185,290,50,"����") ; 
					}
					break;
			}	
		}
	}
}
int main() {
	//��־����
	SYSTEMTIME st;
	GetLocalTime(&st);
	std::stringstream ss;
	ss << "logs\\"
	   << std::setw(2) << std::setfill('0') << st.wMonth  // �·ݲ���
	   << std::setw(2) << std::setfill('0') << st.wDay      // ���ڲ���
	   << std::setw(2) << std::setfill('0') << st.wHour       // Сʱ����
	   << std::setw(2) << std::setfill('0') << st.wMinute       // ���Ӳ���
	   << ".txt";
	   cout<< (windows_width+2) * map_size+logo_size+100+15*map_size+3<<" "<<(windows_height+1) * map_size+logo_size+150<<endl;
	initgraph((windows_width+2) * map_size+logo_size+100+15*map_size+3, (windows_height+1) * map_size+logo_size+150,EX_SHOWCONSOLE);
	std::string narrowPath = ss.str();
	ofstream outFile(narrowPath.c_str());
	int witchship=1;
	bool welcome_back_commander=false;
	srand(time(0));
	number_mod_building=GetPrivateProfileInt("game","game_number",7,"mode\\fuck_number.ini");
	number_mod_ship=GetPrivateProfileInt("ship","ship_number",1,"mode\\fuck_number.ini");
	people_player.all_money=100;
	initAIStrategy();
	//��������
	loadimage(&map_dx_draw[1],_T("mode\\Topography\\lu.png"));
	loadimage(&map_dx_draw[0],_T("mode\\Topography\\hai.png"));
	loadimage(&map_dx_draw[2],_T("mode\\Topography\\yun.png"));
	loadimage(&sp_logo[0],_T("mode\\Topography\\empty.png"));
	loadimage(&sp_logo[2],_T("mode\\Topography\\empty_2.png"));
	loadimage(&sp_logo[1],_T("mode\\Topography\\logo_jz.png"));
	loadimage(&sp_logo[3],_T("mode\\Topography\\zhongchen.jpg"));
	loadimage(&sp_logo[4],_T("mode\\Topography\\key.png"));
	loadimage(&sp_logo[5],_T("mode\\Topography\\r.png"));
	loadimage(&sp_logo[6],_T("mode\\Topography\\l.png"));
	ifstream read;
	////read.open("mode\\fuck_nemeber.txt");
	//read>>number_mod_building;
	//read.close();
	//���벢��ʼ��������Ϣ
	building_template building[number_mod_building+1];//��1��Խ��
	ship_template ship[number_mod_ship+1];
	AI_player.all_money=150;
	war=true;
	//���뽨��
	for (int i = 0; i <=number_mod_building; i++) {
		//����ͼ��
		string path="mode\\build\\" + to_string(i) + "\\Animation\\logo.png";
		loadimage(&building[i].logo, path.c_str());
		//����ر�
		path = "mode\\build\\" + to_string(i) + "\\Animation\\Animation.ini";
		building[i].dh_return=GetPrivateProfileInt("zhen","nenember",1,path.c_str());
		for(int j=0; j<=building[i].dh_return; j++) {
			path = "mode\\build\\" + to_string(i) + "\\Animation\\m_p"+to_string(j)+".png";
			loadimage(&building[i].map_picture[j], path.c_str());
		}
		building[i].map_picture[0]=building[i].map_picture[1];
		path="mode\\build\\"+to_string(i)+"\\buildingconfig.ini";
		building[i].add_food=GetPrivateProfileInt("add","add_food",0,path.c_str());
		building[i].add_money=GetPrivateProfileInt("add","add_money",0, path.c_str());
		building[i].add_people=GetPrivateProfileInt("add","add_people",0,path.c_str());
		building[i].add_pollution=GetPrivateProfileInt("add","add_pollution",0,path.c_str());
		building[i].add_xl=GetPrivateProfileInt("add","add_xl",0,path.c_str());
		building[i].add_xl=1.0*building[i].add_xl/10;
		building[i].cost_money=GetPrivateProfileInt("cost","cost_money",0,path.c_str());
		building[i].cost_can_use_people=GetPrivateProfileInt("cost","cost_can_use_people",0,path.c_str());
		building[i].kind=GetPrivateProfileInt("kind","building_kind",0,path.c_str());
		if(building[i].kind==1) {
			makebuilding[i_1]=i;
			outFile<<i<<endl;
			i_1++;
		}

	}
	//��������
	for (int i = 1; i <=2; i++) {
		string path="music\\" + to_string(i) + "\\p.PNG";
		loadimage(&music_list[i].p, path.c_str());
	} 
	//���뵥λ
	for (int i = 0; i <=number_mod_ship; i++) {
		//����ͼ��
		string path="mode\\ship\\" + to_string(i) + "\\Animation\\logo.png";
		loadimage(&ship[i].logo, path.c_str());
		//����ر�
		path = "mode\\ship\\" + to_string(i) + "\\Animation\\Animation.ini";
		ship[i].dh_return=GetPrivateProfileInt("zhen","number",1,path.c_str());
		for(int j=0; j<=ship[i].dh_return; j++) {
			path = "mode\\ship\\" + to_string(i) + "\\Animation\\m_p"+to_string(j)+".png";
			loadimage(&ship[i].map_picture[j], path.c_str());
		}
		ship[i].map_picture[0]=building[i].map_picture[1];
		path="mode\\ship\\"+to_string(i)+"\\shipconfig.ini";
		ship[i].arm_long=GetPrivateProfileInt("ship","arm_long",0,path.c_str());
		ship[i].walk_long=GetPrivateProfileInt("ship","walk_long",0,path.c_str());
		ship[i].swim=GetPrivateProfileInt("can_you_swim","YorN",0,path.c_str());
		ship[i].cost_money=GetPrivateProfileInt("cost","cost_money",0,path.c_str());
	}
	setlinecolor(RED);//��Ϊ��ɫ
	setlinestyle(PS_SOLID | PS_ENDCAP_SQUARE, 3);
	outFile<<"building"<<endl;
	for(int i=1; i<=number_mod_building; i++) {
		outFile<<"-------------"<<i<<"-------------"<<endl;
		outFile<<"����ʳ��"<<building[i].add_food<<endl;
		outFile<<"����Ǯ"<<building[i].add_money<<endl;
		outFile<<"������"<<building[i].add_people<<endl;
		outFile<<"����Ч��"<<building[i].add_xl<<endl;
		outFile<<"������Ⱦ"<<building[i].add_pollution<<endl;
		outFile<<"�����˿�"<<building[i].cost_can_use_people<<endl;
		outFile<<"����Ǯ"<<building[i].cost_money<<endl;
		outFile<<"����"<<building[i].kind<<endl<<endl;
	}
	outFile<<"ship"<<endl;
	for(int i=1; i<=number_mod_ship; i++) {
		outFile<<"-------------"<<i<<"-------------"<<endl;
		outFile<<"������Χ"<<ship[i].arm_long<<endl;
		outFile<<"����"<<ship[i].walk_long<<endl;
	}
	//��Ϸ������ 
	//��Ϸǰ�ض����
	for(int i=0;i<13;i++){
		for(int j=0;j<13;j++){
			map_weather[i][j]=rand()%2+1;
		}
	}
	putimage(0,windows_height*map_size+logo_size+20,&sp_logo[3]); 
	settextcolor(BLACK);
	setbkcolor(WHITE); 
	settextstyle(15, 0, "����");
	 
	people_player.all_money=10000000;
	setbkcolor(WHITE);
	cleardevice();
	mciSendString(TEXT("open music\\1\\m.mp3 alias 1"),NULL,0,NULL);
	mciSendString(TEXT("open music\\2\\m.mp3 alias 2"),NULL,0,NULL);
	mciSendString(TEXT("open music\\strat\\win95.wav alias 3"),NULL,0,NULL);
	start_UI();
	mciSendString(TEXT("play 1"),NULL,0,NULL);
	while(1) {
		zhen++;
		zhen=zhen%10;
		if(zhen==1) {
		
			game_time++;
			game_time=game_time%1500;
			if(zhongcheng<6&&game_time%1500==0&&people_player.worker>10){
			    for(int i=0;i<50;i++){
			        if(player_ship_pool[i].use==false){
			            player_ship_pool[i].use=true;
				        player_ship_pool[i].kind=2;
				        for(int j=0;j<50;j++){
				            if(player_shipbuilding_pool[j].use==true){
			                    player_ship_pool[i].x=player_shipbuilding_pool[j].outx;
			                    player_ship_pool[i].y=player_shipbuilding_pool[j].outy;
			                    break;
			                }	
					    }
			            for(int j=0;j<50;j++){
		               		 if(AI_shipbuilding_pool[j].use==true){	
				                player_ship_pool[i].dx=AI_shipbuilding_pool[j].outx;
				                player_ship_pool[i].dy=AI_shipbuilding_pool[j].outy;
				                break;
			                }	
			            }
				            // ����·������ͳ�ʼ��
		            	player_ship_pool[i].path = find_path(player_ship_pool[i].x, player_ship_pool[i].y, player_ship_pool[i].dx, player_ship_pool[i].dy);
			       		if (!player_ship_pool[i].path.empty()) {
			            	player_ship_pool[i].path_index = 1; // �ӵ�һ��·���㿪ʼ
			        	} else {
		               		player_ship_pool[i].path_index = -1;
		            	}
			            break;
			        }
					
			    }
			}
			if(game_time%1500==0) {
				wind_think++;
				outFile<<"==============================================="<<endl;
				outFile<<"��ʼ���������Դͳ��"<<endl;

				int number_makefood=0;
				int number_makepeople=0;
				int number_makemoney=1;
				
				int number_pollution=0;
				double number_makexl=1;
				double maybemoney=0;
				int kind_makemoney=0;
				for(int i=0; i<50; i++) {
					if(player_building_pool[i].use==true) {
						if(player_building_pool[i].Degree<=0){
							player_building_pool[i].use=false;
							for(int j=0;j<50;j++){
								if(AI_ship_pool[j].use&&AI_ship_pool[j].war_object==i){
									AI_ship_pool[j].war=false;
								}
							}
						}
						if(player_building_pool[i].kindof_building==1){
							cout<<player_building_pool[i].x<<" "<<player_building_pool[i].y<<endl; 
							for(int j=0;j<50;j++){
								if(AI_ship_pool[j].use==true){
									if(how_long(player_building_pool[i].x,AI_ship_pool[j].x,player_building_pool[i].y,AI_ship_pool[j].y)<=3){
										
										if(AI_ship_pool[j].Degree>=0){
											AI_ship_pool[j].Degree-=30;
											cout<<AI_ship_pool[j].Degree;
											for(int k=0;k<20;k++){
												if(light[k].use==false){
													light[k].x1=AI_ship_pool[j].x;
													light[k].y1=AI_ship_pool[j].y;
													light[k].x2=player_building_pool[i].x;
													light[k].y2=player_building_pool[i].y;
											
													light[k].use=true;
													break;
												}
											}
										}
										else{
											AI_ship_pool[i].use=false;
										}
									}
								}
							}
						}
						maybemoney+=building[player_building_pool[i].kindof_building].add_money;
						number_makepeople+=building[player_building_pool[i].kindof_building].add_people;
						number_pollution+=building[player_building_pool[i].kindof_building].add_pollution;
						number_makexl+=1.0*building[player_building_pool[i].kindof_building].add_xl;
						number_makefood+=building[player_building_pool[i].kindof_building].add_food*map_weather[player_building_pool[i].y][player_building_pool[i].x];

						if(building[player_building_pool[i].kindof_building].add_money>0) {
							number_makemoney++;
							kind_makemoney=i;
						}
					}


				}
				people_player.all_people=number_makepeople;
				people_player.all_pollution=number_pollution;
				people_player.food=number_makefood;
				people_player.all_pollution=number_pollution;
				people_player.all_xl= number_makexl;
				people_player.worker=min(people_player.food,people_player.all_people);
				if(people_player.worker>number_makemoney*building[kind_makemoney].cost_can_use_people) {
					people_player.all_money+=people_player.all_xl*maybemoney;
				} else {
					people_player.all_money+=1.0*(people_player.worker/number_makemoney*building[kind_makemoney].cost_can_use_people)*people_player.all_xl*enqing_money;
				}
				outFile<<"���"<<endl;
				outFile<<"==============================================="<<endl;
				outFile<<"��ʼ����AI��Դͳ��"<<endl;
				number_makefood=0;
				number_makepeople=0;
				number_makemoney=1;
				number_pollution=0;
				number_makexl=1;
				maybemoney=0;
				kind_makemoney=0;

				for(int i=0; i<10; i++) {
					AIbuilding_number[i]=0;
				}
				outFile<<"ͳ�ƻغ�������"<<endl;
				for(int i=0; i<50; i++) {
					if(AI_building_pool[i].use==true) {
						if(AI_building_pool[i].Degree<=0){
							AI_building_pool[i].use=false;
							for(int j=0;j<50;j++){
								if(player_ship_pool[j].use&&player_ship_pool[j].war_object==i){
									player_ship_pool[j].war=false;
								}
							}
						}
						if(AI_building_pool[i].kindof_building==1){
							for(int j=0;j<50;j++){
								if(player_ship_pool[j].use==true){
									if(how_long(AI_building_pool[i].x,player_ship_pool[j].x,AI_building_pool[i].y,player_ship_pool[j].y)<=3){
											if(player_ship_pool[j].Degree>=10){
											player_ship_pool[j].Degree-=30;
											
										}
										else{
											player_ship_pool[j].use=false;
										}
									}
								}
							}
						}
						int kind= AI_building_pool[i].kindof_building; 
						outFile<<"�������"<<building[kind].add_money<<endl;
						maybemoney+=         building[kind].add_money;
						outFile<<"�ۼ�"<< maybemoney<<endl;
						number_makepeople +=building[kind].add_people;
						number_pollution  +=building[kind].add_pollution;
						number_makexl     +=building[kind].add_xl;
						number_makefood   +=building[kind].add_food;
						AIbuilding_number[AI_building_pool[i].kindof_building]++;
						if(building[ AI_building_pool[i].kindof_building].add_money>0) {
							number_makemoney++;
							kind_makemoney=2;
						}
					}
				}
				outFile<<"���"<<endl;
				outFile<<"��ֵ"<<endl;
				AI_player.all_people=number_makepeople;
				AI_player.all_pollution=number_pollution;
				AI_player.food=number_makefood;
				AI_player.all_pollution=number_pollution;
				AI_player.all_xl= number_makexl;
				AI_player.worker=min(AI_player.food,AI_player.all_people);
				outFile<<"���"<<endl;
				outFile<<"���ù���"<<AI_player.worker<<endl;
				if(AI_player.worker>=(number_makemoney*building[kind_makemoney].cost_can_use_people)) {
					outFile<<"���˳������"<<endl;
					outFile<<"����"<<maybemoney <<endl;
					outFile<<"Ч��"<< AI_player.all_xl<<endl;
					AI_player.all_money+=AI_player.all_xl*maybemoney;
				} else {
					outFile<<"���˲��������"<<endl;
					outFile<<"����"<< maybemoney<<endl;
					outFile<<"Ч��"<< AI_player.all_xl<<endl;
					AI_player.all_money+=1.0*min(1.0, (double)AI_player.worker / (number_makemoney * building[kind_makemoney].cost_can_use_people))*AI_player.all_xl*maybemoney;
				}
				outFile<<"���"<<endl;
				outFile<<AI_player.all_money<<endl;
				outFile<<"==============================================="<<endl;
				UI_number_makemoney=number_makemoney;
			}
			AI_player.all_money=10000;
if (game_time % 1500 == 0) {
    outFile << "AI��ʼȷ�Ͻ���" << endl;
    bool found = false;
    int x_j = 0;
    war=false;
    // ��������ƽ��
    evaluateForceBalance();
    outFile << "����ƽ������: " << aiStrategy.forceBalance << "���׶�: " << aiStrategy.phase << endl;
    
    // �����Ƿ񹥻�
    bool shouldAttack = false;
    
    // ����1: �������ƣ�AI��ֻ��������Ҷ�����2�ң�
    if (aiStrategy.forceBalance >= 2&&AI_player.all_money >= people_player.all_money * 1.5) {
        shouldAttack = true;
        outFile << "AI������������������" << endl;
    }
    // ����3: �ض��������ƣ�AI������2��������
    int shipyardCount = 0;
    for (int i = 0; i < 50; i++) {
        if (AI_shipbuilding_pool[i].use && AI_shipbuilding_pool[i].kindof_building == 7) {
            shipyardCount++;
        }
    }
    if (shipyardCount >= 2) {
        shouldAttack = true;
        outFile << "AI����������������������" << endl;
    }
    
    // ����4: ������㣨��Ҵ�������1����
    int playerShipyardCount = 0;
    for (int i = 0; i < 50; i++) {
        if (player_shipbuilding_pool[i].use && player_shipbuilding_pool[i].kindof_building == 7) {
            playerShipyardCount++;
        }
    }
    // ����ս��״̬
    war = shouldAttack;
    aiStrategy.phase = shouldAttack ? 2 : (aiStrategy.forceBalance > 0 ? 1 : 0);
    outFile << "���վ��ߣ�ս��״̬: " << war << "���׶�: " << aiStrategy.phase << endl;
    
    // ��鴬������
    int aiShipyardCount = 0;
    for (int i = 0; i < 50; i++) {
        if (AI_shipbuilding_pool[i].use && AI_shipbuilding_pool[i].kindof_building == 7) {
            aiShipyardCount++;
        }
    }
    outFile << "AI��������: " << aiShipyardCount << endl;
    
    // ���ݽ׶ξ�����Ϊ
    if (aiStrategy.phase == 2) { // �����׶�
        outFile << "AI���빥���׶�" << endl;
        
        // ����Ƿ��п��õĴ���
        bool hasShipyard = (aiShipyardCount > 0);
        
        if (!hasShipyard) {
            outFile << "AIû�д��������Ƚ��촬��" << endl;
            // ���ý��촬��
            x_j = 7; // ��������
            
            // �����ҵ����ʵ�λ�ý��촬��
            int rnx = 0;
            int rny = 0;
            int outx = 0;
            int outy = 0;
            int attempts = 0;
            int max_attempts = 100;
            bool foundShipyardLocation = false;
            
            // Ѱ�Һ��ʵ�λ��
            while (!foundShipyardLocation && attempts < max_attempts) {
                attempts++;
                rnx = rand() % (windows_width / 2);
                rny = rand() % (windows_height-2);
                
                if (rny >= 0 && rny < windows_height && rnx >= 0 && rnx < windows_width && 
                    map_dx[rny][rnx] == 1 && PhantomRoweronaDustySea(rnx, rny, 7)) {
                    
                    bool overlap = false;
                    for (int i = 0; i < 50; i++) {
                        if (AI_building_pool[i].use && AI_building_pool[i].x == rnx && AI_building_pool[i].y == rny) {
                            overlap = true;
                            break;
                        }
                    }
                    
                    if (!overlap) {
                        foundShipyardLocation = true;
                        
                        // ȷ������λ��
                        if (PhantomRoweronaDustySea(rnx, rny, 7)) {
                            int tryDirections[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
                            for (int j = 0; j < 4; j++) {
                                int newX = rnx + tryDirections[j][0];
                                int newY = rny + tryDirections[j][1];
                                if (newX >= 0 && newX <= windows_height && newY >= 0 && newY <= windows_width && 
                                    map_dx[newY][newX] == 0) {
                                    outx = newX;
                                    outy = newY;
                                    break;
                                }
                            }
                        }
                        
                        // ���촬��
                        for (int i = 0; i < 50; i++) {
                            if (!AI_shipbuilding_pool[i].use) {
                                if (AI_player.all_money >= building[7].cost_money) {
                                    AI_shipbuilding_pool[i].use = true;
                                    AI_shipbuilding_pool[i].x = rnx;
                                    AI_shipbuilding_pool[i].y = rny;
                                    AI_shipbuilding_pool[i].outx = outx;
                                    AI_shipbuilding_pool[i].outy = outy;
                                    AI_shipbuilding_pool[i].kindof_building = 7;
                                    AI_player.all_money -= building[7].cost_money;
                                    outFile << "AI�����˴����� " << rnx << "," << rny << "�������� " << outx << "," << outy << endl;
                                    break;
                                } else {
                                    outFile << "AI�ʽ��㣬�޷����촬������Ҫ: " << building[7].cost_money 
                                           << "����ǰ: " << AI_player.all_money << endl;
                                }
                            }
                        }
                    }
                }
            }
            
            if (!foundShipyardLocation) {
                outFile << "AI�޷��ҵ����ʵ�λ�ý��촬��" << endl;
            }
        } else {
            outFile << "AI���д��������Խ���ս��" << endl;
            
            // ����ʽ��Ƿ��㹻����ս��
            if (AI_player.all_money >= ship[1].cost_money * 2) {
                outFile << "AI�ʽ���㣬��ʼ����ս��" << endl;
                // ���Խ�������ս��
                int shipsBuilt = 0;
                for (int i = 0; i < 50 && shipsBuilt < 2; i++) {
                    if (AI_shipbuilding_pool[i].use) {
                        for (int j = 0; j < 50; j++) {
                            if (!AI_ship_pool[j].use) {
                                outFile << "�ڴ��� " << i << " ����ս�� " << j << endl;
                                AI_player.all_money -= ship[1].cost_money;
                                AI_ship_pool[j].use = true;
                                AI_ship_pool[j].x = AI_shipbuilding_pool[i].outx;
                                AI_ship_pool[j].y = AI_shipbuilding_pool[i].outy;
                                AI_ship_pool[j].kind = 1;
                                AI_ship_pool[j].Degree = 100;
                                
                                // ѡ��Ŀ��
                                int target = chooseAITarget(AI_ship_pool[j].x, AI_ship_pool[j].y);
    if (target != -1) {
        // Ѱ��Ŀ�꽨��������ˮ���
        int targetX = player_building_pool[target].x;
        int targetY = player_building_pool[target].y;
        int waterX = -1, waterY = -1;
        float minDistance = 999999.0f;
        
        // ��Ŀ�꽨����Χ3x3��Χ��Ѱ�������ˮ���
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int nx = targetX + dx;
                int ny = targetY + dy;
                if (nx >= 0 && nx < windows_width && ny >= 0 && ny < windows_height && 
                    map_dx[ny][nx] == 0) {
                    float distance = sqrt(pow(AI_ship_pool[j].x - nx, 2) + 
                                         pow(AI_ship_pool[j].y - ny, 2));
                    if (distance < minDistance) {
                        minDistance = distance;
                        waterX = nx;
                        waterY = ny;
                    }
                }
            }
        }
        
        if (waterX != -1 && waterY != -1) {
            outFile << "�ҵ�ˮ���: " << waterX << "," << waterY << " ����Ŀ��: " 
                   << abs(targetX - waterX) + abs(targetY - waterY) << endl;
            
            AI_ship_pool[j].war_object = target;
            AI_ship_pool[j].war = true;
            AI_ship_pool[j].dx = waterX;
            AI_ship_pool[j].dy = waterY;
            
            // ����·��
            AI_ship_pool[j].path = find_path(
                AI_ship_pool[j].x, 
                AI_ship_pool[j].y,
                AI_ship_pool[j].dx,
                AI_ship_pool[j].dy
            );
            
            if (!AI_ship_pool[j].path.empty()) {
                AI_ship_pool[j].path_index = 1;
                outFile << "·������ɹ���·��������: " << AI_ship_pool[j].path.size() << endl;
            } else {
                outFile << "·������ʧ��" << endl;
                AI_ship_pool[j].war = false; // �޷�����Ŀ�꣬ȡ������
            }
        } else {
            outFile << "Ŀ�긽��û��ˮ��㣬�޷�����" << endl;
            AI_ship_pool[j].war = false;
        }
    } else {
        outFile << "û���ҵ����ʵ�Ŀ��" << endl;
        AI_ship_pool[j].war = false;
    }
                                
                                shipsBuilt++;
                                break;
                            }
                        }
                    }
                }
            } else {
                outFile << "AI�ʽ��㣬�޷�����ս������ǰ�ʽ�: " << AI_player.all_money 
                       << "�������ʽ�: " << ship[1].cost_money * 2 << endl;
                
                // ������ǹ����׶Σ���ִ�о��úͷ�չ�߼�
                if (AI_player.all_pollution >= 15) {
                    x_j = 5;
                } else if (AIbuilding_number[2] % (3*(AIbuilding_number[4]+1)) == 0 && AIbuilding_number[2] != 0) {
                    x_j = 4;
                } else if (AI_player.worker > AIbuilding_number[2] * building[2].cost_can_use_people) {
                    x_j = 2;
                } else if (AI_player.worker < AIbuilding_number[2] * building[2].cost_can_use_people) {
                    if (AI_player.all_people >= AI_player.food) {
                        x_j = 3;
                    } else {
                        x_j = 6;
                    }
                } else if (AI_player.food == 0) {
                    x_j = 3;
                } else if (AI_player.all_people == 0) {
                    x_j = 6;
                } else {
                    x_j = 2;
                }
                
                // ���Խ��쾭�ý���
                int rnx = 0;
                int rny = 0;
                int attempts = 0;
                int max_attempts = 100;
                bool foundLocation = false;
                
                // Ѱ�Һ��ʵ�λ��
                while (!foundLocation && attempts < max_attempts) {
                    attempts++;
                    rnx = rand() % (windows_width / 2);
                    rny = rand() % (windows_height-2);
                    
                    if (rny >= 0 && rny < windows_height && rnx >= 0 && rnx < windows_width && 
                        map_dx[rny][rnx] == 1 && PhantomRoweronaDustySea(rnx, rny, x_j)) {
                        
                        bool overlap = false;
                        for (int i = 0; i < 50; i++) {
                            if (AI_building_pool[i].use && AI_building_pool[i].x == rnx && AI_building_pool[i].y == rny) {
                                overlap = true;
                                break;
                            }
                        }
                        
                        if (!overlap) {
                            foundLocation = true;
                            
                            // ���콨��
                            for (int i = 0; i < 50; i++) {
                                if (AI_building_pool[i].use == false) {
                                    if (AI_player.all_money >= building[x_j].cost_money) {
                                        AI_building_pool[i].use = true;
                                        AI_building_pool[i].x = rnx;
                                        AI_building_pool[i].Degree = 100;
                                        AI_building_pool[i].y = rny;
                                        AI_building_pool[i].kindof_building = x_j;
                                        AI_player.all_money -= building[x_j].cost_money;
                                        outFile << "AI�����˽��� " << x_j << " �� " << rnx << "," << rny << endl;
                                        break;
                                    } else {
                                        outFile << "AI�ʽ��㣬�޷����콨������Ҫ: " << building[x_j].cost_money 
                                               << "����ǰ: " << AI_player.all_money << endl;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    } else { // �ǹ����׶Σ���չ�����ţ�
        outFile << "AI���ڷ�չ�׶�" << endl;
        if (AI_player.all_pollution >= 15) {
            x_j = 5;
        } else if (AIbuilding_number[2] % (3*(AIbuilding_number[4]+1)) == 0 && AIbuilding_number[2] != 0) {
            x_j = 4;
        } else if (AI_player.worker > AIbuilding_number[2] * building[2].cost_can_use_people) {
            x_j = 2;
        } else if (AI_player.worker < AIbuilding_number[2] * building[2].cost_can_use_people) {
            if (AI_player.all_people >= AI_player.food) {
                x_j = 3;
            } else {
                x_j = 6;
            }
        } else if (AI_player.food == 0) {
            x_j = 3;
        } else if (AI_player.all_people == 0) {
            x_j = 6;
        } else {
            x_j = 2;
        }
        
        // ���Խ��콨��
        int rnx = 0;
        int rny = 0;
        int attempts = 0;
        int max_attempts = 100;
        bool foundLocation = false;
        
        // Ѱ�Һ��ʵ�λ��
        while (!foundLocation && attempts < max_attempts) {
            attempts++;
            rnx = rand() % (windows_width / 2);
            rny = rand() % (windows_height-2);
            
            if (rny >= 0 && rny < windows_height && rnx >= 0 && rnx < windows_width && 
                map_dx[rny][rnx] == 1 && PhantomRoweronaDustySea(rnx, rny, x_j)) {
                
                bool overlap = false;
                for (int i = 0; i < 50; i++) {
                    if (AI_building_pool[i].use && AI_building_pool[i].x == rnx && AI_building_pool[i].y == rny) {
                        overlap = true;
                        break;
                    }
                }
                
                if (!overlap) {
                    foundLocation = true;
                    
                    // ���콨��
                    for (int i = 0; i < 50; i++) {
                        if (AI_building_pool[i].use == false) {
                            if (AI_player.all_money >= building[x_j].cost_money) {
                                AI_building_pool[i].use = true;
                                AI_building_pool[i].x = rnx;
                                AI_building_pool[i].Degree = 100;
                                AI_building_pool[i].y = rny;
                                AI_building_pool[i].kindof_building = x_j;
                                AI_player.all_money -= building[x_j].cost_money;
                                outFile << "AI�����˽��� " << x_j << " �� " << rnx << "," << rny << endl;
                                break;
                            } else {
                                outFile << "AI�ʽ��㣬�޷����콨������Ҫ: " << building[x_j].cost_money 
                                       << "����ǰ: " << AI_player.all_money << endl;
                            }
                        }
                    }
                }
            }
        }
        
        if (!foundLocation) {
            outFile << "AI�޷��ҵ����ʵ�λ�ý��콨��" << endl;
        }
    }
    
    outFile << "===============================================" << endl;
}
			
			if(game_time%100==0) {
				// �ƶ���Ҵ�ֻ����·����
				for (int i = 0; i < 50; i++) {
					if (player_ship_pool[i].use && player_ship_pool[i].path_index >= 0) {
						// ����Ƿ���·����
						if (player_ship_pool[i].path_index < player_ship_pool[i].path.size()) {
							// �ƶ�����һ��·����
							player_ship_pool[i].x = player_ship_pool[i].path[player_ship_pool[i].path_index].first;
							player_ship_pool[i].y = player_ship_pool[i].path[player_ship_pool[i].path_index].second;
							player_ship_pool[i].path_index++;
						} else {
							// �����յ㣬���·��
							player_ship_pool[i].path.clear();
							player_ship_pool[i].path_index = -1;
							if(player_ship_pool[i].kind==2){
								south_people+=10;
								player_ship_pool[i].use=false;
							}
						}
					}
					if(player_ship_pool[i].use&&player_ship_pool[i].war==true){
						int war_x=AI_building_pool[player_ship_pool[i].war_object].x;
						int war_y=AI_building_pool[player_ship_pool[i].war_object].y;
						if(max(	player_ship_pool[i].x,war_x)-min(player_ship_pool[i].x,war_x)+max(player_ship_pool[i].y,war_y)-min(player_ship_pool[i].y,war_y)<=ship[player_ship_pool[i].kind].arm_long*2){
							AI_building_pool[player_ship_pool[i].war_object].Degree-=10;
						}
						else{
							player_ship_pool[i].war=false;
						}
					}
				}

				// �ƶ�AI��ֻ����·����
				for (int i = 0; i < 50; i++) {
					if (AI_ship_pool[i].use && AI_ship_pool[i].path_index >= 0) {
						// ����Ƿ���·����
						if (AI_ship_pool[i].path_index < AI_ship_pool[i].path.size()) {
							// �ƶ�����һ��·����
							AI_ship_pool[i].x = AI_ship_pool[i].path[AI_ship_pool[i].path_index].first;
							AI_ship_pool[i].y = AI_ship_pool[i].path[AI_ship_pool[i].path_index].second;
							AI_ship_pool[i].path_index++;
						} else {
							// �����յ㣬���·��
							AI_ship_pool[i].path.clear();
							AI_ship_pool[i].path_index = -1;
						}
					}
					if(AI_ship_pool[i].use&&AI_ship_pool[i].war==true){
						int war_x=player_building_pool[AI_ship_pool[i].war_object].x;
						int war_y=player_building_pool[AI_ship_pool[i].war_object].y;
						if(max(	AI_ship_pool[i].x,war_x)-min(AI_ship_pool[i].x,war_x)+max(AI_ship_pool[i].y,war_y)-min(AI_ship_pool[i].y,war_y)<=ship[AI_ship_pool[i].kind].arm_long*2){
							player_building_pool[AI_ship_pool[i].war_object].Degree-=10;
						}
					}
				}
			}
			//ͼ�����
			BeginBatchDraw();
			main_out(number_mod_building,building, ship);
			music_player((windows_width+2) * map_size+logo_size,0);
			newspaper(0,(windows_height+1) * map_size+logo_size+25);
			build_building((windows_width+1) * map_size+10,0,building);
			putimage(0,(windows_height+1)*map_size+25,&sp_logo[1]);
			ship_out(0,(windows_height+1)*map_size+25,ship);
			weatcher((windows_width+2) * map_size+logo_size+100,0);
			 drawLightEffects();
			// ����Ϸ��ѭ��������
			for(int i = 0; i < 20; i++) {
    			if (light[i].use) {
       				light[i].duration--;
        			if (light[i].duration <= 0) {
           				light[i].use = false;
        			}
   				}
			}
	
			longlong((windows_width+2) * map_size+logo_size,190);
			zhongcheng=0;
			if(enqing_money>1.5){
				zhongcheng+=1;
			}
			setlinecolor(RED);
			if(map_qk_x<=windows_width&&map_qk_y<=windows_height) {
				if(welcome_back_commander){
					shoot_head(msg.x,msg.y);
				}
				else{
					rectangle(map_qk_x *map_size+5, map_qk_y * map_size+20, (map_qk_x + 1) * map_size+5, (map_qk_y + 1) * map_size+20);
					if(map_qk_x>=11&&map_qk_x<=24&&map_qk_y>=3&&map_qk_y<=16){
						rectangle((map_qk_x-11) *map_size+(windows_width+2) * map_size+logo_size+109, (map_qk_y-3) * map_size+25, (map_qk_x -10) * map_size+(windows_width+2) * map_size+logo_size+109, (map_qk_y -2) * map_size+25);
					}
				}
				
				
			}

			
			

			EndBatchDraw();//������ 
			//����ѡ�� ��λָ�� 
			if(!ifbuild&&!ifship) {
				map_qk_x=(msg.x-5)/map_size;
				map_qk_y=(msg.y-20)/map_size;
			}
			if (peekmessage(&msg, EX_MOUSE)) {
				switch (msg.message) {
					case WM_LBUTTONUP:
						ifmore=false;
						if(!welcome_back_commander) {//��ʼ���͵�λָ�� 
							for(int i=0; i<50; i++) {
								if(player_ship_pool[i].use) {
									if(player_ship_pool[i].x==map_qk_x&&player_ship_pool[i].y==map_qk_y) {
										welcome_back_commander=true;
										player_ship_pool[i].war=false;
										witchship=i;
										outFile<<"year sir"<<endl;
									}
								}
							}
						} else if(welcome_back_commander==true&&map_dx[map_qk_y][map_qk_x]==0&&map_qk_x<=windows_width&&map_qk_y<=windows_height) {
							outFile<<"I am here"<<player_ship_pool[witchship].x<<" "<<player_ship_pool[witchship].y<<endl;
							player_ship_pool[witchship].dy=map_qk_y;
							player_ship_pool[witchship].dx=map_qk_x;
							// ������·��
							player_ship_pool[witchship].path = find_path(player_ship_pool[witchship].x,player_ship_pool[witchship].y,map_qk_x,map_qk_y);

							if (!player_ship_pool[witchship].path.empty()) {
								player_ship_pool[witchship].path_index = 1; // �ӵ�һ��·���㿪ʼ��0�ǵ�ǰλ�ã�
							} else {
								player_ship_pool[witchship].path_index = -1;
							}

							outFile<<"I will go to"<<map_qk_x<<" "<<map_qk_y<<endl;
							welcome_back_commander=false;
						}
						else if(welcome_back_commander==true&&map_dx[map_qk_y][map_qk_x]==1&&map_qk_x<=windows_width&&map_qk_y<=windows_height){
							if(max(	player_ship_pool[witchship].x,map_qk_x)-min(	player_ship_pool[witchship].x,map_qk_x)+max(player_ship_pool[witchship].y,map_qk_y)-min(player_ship_pool[witchship].y,map_qk_y)<=ship[player_ship_pool[witchship].kind].arm_long*2){
								for(int i=0;i<50;i++){
									if(AI_building_pool[i].use==true&&AI_building_pool[i].x==map_qk_x&&AI_building_pool[i].y==map_qk_y){
										player_ship_pool[witchship].war=true;
										player_ship_pool[witchship].war_object=i;
										
										break;
									}
								}
								welcome_back_commander=false;
							}
							else{
								welcome_back_commander=false;
							}
						}
						//���½��Ҫ������ 
						 if(ifbuild==false&&map_qk_x<=windows_width&&map_dx[map_qk_y][map_qk_x]!=0&&fuck_Hyperspatial_Overlapping_Architecture()&&map_qk_x>=windows_width/2) {
							ifbuild=true;
						}
						
						
						//ѡ���� 
						else if(msg.y>=(windows_height+1)*map_size&&ifship&&msg.y<=(windows_height+1)*map_size+logo_size+10) {
							int key_ship=msg.x/logo_size;
							if(people_player.all_money>=ship[key_ship].cost_money) {
								people_player.all_money-=ship[key_ship].cost_money;

								for(int i=0; i<50; i++) {
									if(player_ship_pool[i].use==false) {
										player_ship_pool[i].use=true;
										player_ship_pool[i].x=player_shipbuilding_pool[now_shipbuilding].outx;
										player_ship_pool[i].y=player_shipbuilding_pool[now_shipbuilding].outy;
										player_ship_pool[i].dx=player_shipbuilding_pool[now_shipbuilding].outx;
										player_ship_pool[i].dy=player_shipbuilding_pool[now_shipbuilding].outy;
										player_ship_pool[i].kind=key_ship;
										player_ship_pool[i].Degree=100;
										break;
									}
								}
							}
						} else if(msg.x>(windows_width+1)*map_size&&ifbuild==true) {//ѡ������ 
							int key=(msg.y-20)/logo_size;
							key++;
							outFile<<key<<endl;
							if(people_player.all_money>=building[key].cost_money&&map_dx[map_qk_y][map_qk_x]==1) {
								
								outFile<<building[key].cost_money<<endl;
								outFile<<check_ifmake(key);
								for(int i=0; i<50; i++) {
									if(key==7) {
										if(player_shipbuilding_pool[i].use==false) {//������׼ 
											bool b100=false;
											if(map_dx[map_qk_y+1][map_qk_x]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x;
												player_shipbuilding_pool[i].outy=map_qk_y+1;
												b100=true;
											}
											if(map_dx[map_qk_y-1][map_qk_x]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x;
												player_shipbuilding_pool[i].outy=map_qk_y-1;
												b100=true;
											}
											if(map_dx[map_qk_y][map_qk_x-1]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x-1;
												player_shipbuilding_pool[i].outy=map_qk_y;
												b100=true;
											}
											if(map_dx[map_qk_y][map_qk_x+1]==0) {
												player_shipbuilding_pool[i].outx=map_qk_x+1;
												player_shipbuilding_pool[i].outy=map_qk_y;
												b100=true;
											}
											if(b100) {
												player_shipbuilding_pool[i].use=true;
												player_shipbuilding_pool[i].kindof_building=key;
												player_shipbuilding_pool[i].x=map_qk_x;
												player_shipbuilding_pool[i].y=map_qk_y;
												ifbuild=false;
												b100=false;
												break;
											}
										}
									} else if(!check_ifmake(key)) {
										outFile<<check_ifmake(key);
										if(player_building_pool[i].use==false) {
											people_player.all_money-=building[key].cost_money;
											player_building_pool[i].use=true;
											player_building_pool[i].kindof_building=key;
											player_building_pool[i].x=map_qk_x;
											player_building_pool[i].y=map_qk_y;
											player_building_pool[i].Degree=100;
											ifbuild=false;
											break;
										}
									}

								}
							}
						} else if(!ifbuild&&map_dx[map_qk_y][map_qk_x]) {
							for(int i=0; i<50; i++) {
								if(player_shipbuilding_pool[i].use==true) {
									if(player_shipbuilding_pool[i].x==map_qk_x&&player_shipbuilding_pool[i].y==map_qk_y) {
										ifship=true;
										now_shipbuilding=i;
										break;
									}
								}
							}
						}
						else if(msg.x>(windows_width+2) * map_size+logo_size&&msg.y<=90){
							string name="close "+to_string((this_is_real_music)%2+1);
							cout<<(this_is_real_music)%2+1<<endl;
							cout<<name<<endl;
							mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							name="open music\\"+to_string((this_is_real_music)%2+1)+"\\m.mp3 alias "+to_string((this_is_real_music)%2+1);
							mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							if(msg.x<(windows_width+2) * map_size+logo_size+50&&msg.y<=45){
								this_is_real_music--;
							}
							else if(msg.x>=(windows_width+2) * map_size+logo_size+50&&msg.y<=45){
								this_is_real_music++;
							}
							else if(msg.y>45){
								if(ifmusic==false){
									ifmusic=true;
								}
								else{
									ifmusic=false;
								}
							}
							if(ifmusic){
								name="play "+to_string((this_is_real_music)%2+1);
								cout<<(this_is_real_music)%2+1<<endl;
								cout<<name<<endl;
								mciSendString(TEXT(name.c_str()),NULL,0,NULL);
							}
						}
						else if(msg.x>(windows_width+2) * map_size+logo_size+100&&msg.x<(windows_width+2) * map_size+logo_size+100+15*map_size+3&&msg.y>(windows_width-9)* map_size+20){
							cout<<"123"<<endl;
							if(msg.y<=(windows_width-9)* map_size+130){
								if(msg.y<=(windows_width-9)* map_size+70){
									cout<<"1"<<endl;
									if(wind_think>=10){
										wind_think-=10;
										war=false;
									}
								}
								else{
									cout<<"2"<<endl;
									if(wind_think>=10){
										wind_think-=10;
										people_player.all_money+=50;
									}
								}
								
							}
							else if(msg.y>=(windows_width-9)* map_size+150&&msg.y<=(windows_width-9)* map_size+250){
								cout<<"3"<<endl;
								if(wind_think>=10){
									for(int i=0;i<50;i++){
									if(player_shipbuilding_pool[i].use==true){
										for(int j=0;j<50;j++){
											if(player_ship_pool[j].use==false){
												player_ship_pool[j].Degree=100;
												player_ship_pool[j].use=true;
												player_ship_pool[j].kind=1;
												wind_think-=10;
												player_ship_pool[j].x=player_shipbuilding_pool[i].outx;
												player_ship_pool[j].y=player_shipbuilding_pool[i].outy;
												break;
											}
											break;
										}
									}
								}
								}
								
							}
						}
						break;
					case WM_RBUTTONUP:
						ifbuild=false;
						ifship=false;
						ifmore=false;
						welcome_back_commander=false;
						break;
					case WM_LBUTTONDOWN:
						if(msg.y>(windows_height)*map_size+logo_size+80&&msg.y<(windows_height)*map_size+logo_size+185&&msg.x>400+(enqing_money-1)*10&&msg.x<400+(enqing_money-1)*100+20&&msg.x<500){
							if(!ifmore){
								ifmore=true;
								while(ifmore&&msg.x<500&&msg.x>400){
									enqing_money=1+1.0*(msg.x-400)/100;
									cout<<enqing_money<<endl;
									putimage(5,windows_height*map_size+logo_size+68,&sp_logo[3]); 
									outtextxy(190,windows_height*map_size+logo_size+125, zhongcheng_said_c(people_player.all_money).c_str());
									outtextxy(190,windows_height*map_size+logo_size+104, zhongcheng_said_z(people_player.food,people_player.worker).c_str());
									putimage(400+(enqing_money-1)*100,(windows_height+1)*map_size+logo_size+80,&sp_logo[4]);
									peekmessage(&msg, EX_MOUSE);
									if(msg.message==WM_LBUTTONUP){
										ifmore=false;
									}
								}
							}
							
						}
						
				}
			}
		}
	}
	outFile.close();
	return 0;
}

